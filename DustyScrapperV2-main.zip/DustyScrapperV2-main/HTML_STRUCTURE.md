# HTML Structure Documentation - Dusty Scrapper V2

## 🌐 Overview
The HTML provides the foundation for the modern UI with semantic elements and proper accessibility.

## 📁 File: `public/index.html`

## 🏗️ Document Structure

### Document Head
```html
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dusty Scrapper V2 - Modern Data Explorer</title>
    <link rel="stylesheet" href="styles.css">
</head>
```

**Elements**:
- **Meta tags**: Proper viewport and charset settings
- **Title**: "Dusty Scrapper V2 - Modern Data Explorer"
- **CSS Link**: References `styles.css`

## 🎨 Background Elements

### Modern Background
```html
<!-- Modern Background -->
<div class="modern-background"></div>
```
**Purpose**: Creates the main background with gradients and geometric shapes

### Modern Typography Elements
```html
<!-- Modern Typography Elements -->
<div class="modern-text">DATA</div>
<div class="modern-text">EXPLORE</div>
<div class="modern-text">SEARCH</div>
<div class="modern-text">ANALYZE</div>
<div class="modern-text">INSIGHTS</div>
<div class="modern-text">DISCOVER</div>
<div class="modern-text">QUERY</div>
<div class="modern-text">FILTER</div>
```
**Purpose**: Creates ambient background effects with floating text elements
**Positioning**: Each element has specific positioning and animation delays

### Particles Container
```html
<!-- Particles Container -->
<div class="particles-container"></div>
```
**Purpose**: Container for animated particle effects
**JavaScript**: Populated dynamically by the DustyScrapper class

## 📦 Main Container

### Container Wrapper
```html
<div class="container">
    <!-- All main content goes here -->
</div>
```
**Purpose**: Centers and constrains the main content
**Styling**: Max-width 1400px with responsive padding

## 🎯 Header Section

### Header Structure
```html
<header class="modern-header">
    <h1 class="glow-text">Dusty Scrapper V2</h1>
    <p class="subtitle">Modern Data Exploration Platform</p>
</header>
```

**Elements**:
- **Main Title**: Large glowing text with gradient effects
- **Subtitle**: Descriptive text below the main title
- **Styling**: Centered with modern typography

## 🎛️ Controls Section

### Controls Structure
```html
<section class="controls-section">
    <div class="control-group">
        <label for="categorySelect" class="control-label">Select Category</label>
        <select id="categorySelect" class="modern-select">
            <option value="cars">Cars</option>
            <option value="phones">Phones</option>
            <option value="laptops">Laptops</option>
        </select>
    </div>
    
    <div class="control-group">
        <label for="budgetInput" class="control-label">Target Budget</label>
        <input type="number" id="budgetInput" class="modern-input" placeholder="Enter your budget..." min="0">
        <div class="modern-note">Showing up to 20 items closest to your budget</div>
    </div>
    
    <button id="searchButton" class="modern-button">Search Data</button>
</section>
```

**Form Elements**:
- **Category Selector**: Dropdown for choosing data category
- **Budget Input**: Number input for target price
- **Search Button**: Primary action button
- **Helper Text**: Note about result limitations

**Accessibility**:
- Proper label associations
- Input validation attributes
- Semantic HTML structure

## ⏳ Loading Indicator

### Loading Structure
```html
<div id="loadingIndicator" class="loading-indicator hidden">
    <div class="loading-spinner"></div>
    <p>Searching data...</p>
</div>
```

**Elements**:
- **Spinner**: Animated loading indicator
- **Text**: Loading message
- **State**: Hidden by default, shown during API calls

## 📊 Results Section

### Results Structure
```html
<section id="resultsSection" class="results-section hidden">
    <div class="results-header">
        <h2 id="resultsTitle" class="glow-text">Search Results</h2>
        <div id="resultsCount" class="results-count">
            <span class="modern-info">Found: </span>
            <span id="resultCount">0</span>
            <span class="modern-note"> items</span>
        </div>
    </div>
    <div id="resultsContainer" class="results-container"></div>
</section>
```

**Elements**:
- **Results Title**: Dynamic title based on category
- **Results Count**: Shows number of found items
- **Results Container**: Dynamic content area for search results
- **State**: Hidden by default, shown when results are available

## ❌ Error Display

### Error Structure
```html
<div id="errorDisplay" class="error-display hidden">
    <p class="error-text" id="errorText"></p>
</div>
```

**Purpose**: Displays error messages to users
**State**: Hidden by default, shown when errors occur
**Content**: Dynamically populated with error messages

## 🪟 Modal Structure

### Modal Container
```html
<div id="detailsModal" class="modal hidden">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle" class="modal-title"></h3>
            <span id="modalClose" class="modal-close">&times;</span>
        </div>
        <div class="modal-body">
            <div id="modalDetails"></div>
        </div>
    </div>
</div>
```

**Structure**:
- **Modal Container**: Full-screen overlay
- **Modal Content**: Centered content box
- **Modal Header**: Title and close button
- **Modal Body**: Dynamic content area

**Elements**:
- **Modal Title**: Dynamic title for the selected item
- **Close Button**: × symbol for closing modal
- **Modal Details**: Dynamic content showing item specifications

## 🔗 Element IDs and Classes

### Form Elements
- `categorySelect`: Category dropdown selector
- `budgetInput`: Budget input field
- `searchButton`: Search action button

### Display Elements
- `loadingIndicator`: Loading state container
- `resultsSection`: Results display section
- `errorDisplay`: Error message container

### Modal Elements
- `detailsModal`: Modal overlay container
- `modalTitle`: Modal title element
- `modalClose`: Modal close button
- `modalDetails`: Modal content area

### Results Elements
- `resultsTitle`: Results section title
- `resultsCount`: Results count display
- `resultsContainer`: Results grid container

## 📱 Responsive Design Features

### Mobile Considerations
- **Viewport Meta Tag**: Proper mobile scaling
- **Semantic HTML**: Screen reader friendly
- **Touch Targets**: Adequate button sizes
- **Responsive Grid**: Adapts to screen sizes

### Accessibility Features
- **ARIA Labels**: Proper form associations
- **Keyboard Navigation**: Full keyboard support
- **Screen Reader Support**: Semantic HTML structure
- **Focus Management**: Proper focus handling

## 🎨 CSS Integration

### Class Naming Convention
- **modern-**: Prefix for modern theme elements
- **control-**: Prefix for form control elements
- **modal-**: Prefix for modal-related elements
- **results-**: Prefix for results display elements

### State Classes
- **hidden**: Controls element visibility
- **animate-in**: Triggers entrance animations
- **glow**: Enhanced visual effects

## 🔧 JavaScript Integration

### Event Handlers
- **Click Events**: Modal interactions, button clicks
- **Form Events**: Input changes, form submissions
- **Keyboard Events**: Escape key for modal closing

### Dynamic Content
- **Results Rendering**: Dynamic card creation
- **Modal Population**: Dynamic content loading
- **State Management**: Show/hide elements based on state

## 📋 HTML Best Practices

### Semantic Structure
- **Section Elements**: Proper content organization
- **Header Elements**: Clear hierarchy
- **Form Elements**: Proper form structure
- **Button Elements**: Semantic button usage

### Performance Considerations
- **Minimal DOM**: Efficient HTML structure
- **Proper IDs**: Unique element identification
- **Class Reuse**: Efficient CSS class usage
- **Clean Structure**: Maintainable HTML code
