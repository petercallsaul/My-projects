# Frontend JavaScript Documentation - Dusty Scrapper V2

## ⚡ Overview
The frontend uses a class-based architecture with the `DustyScrapper` class managing all functionality.

## 📁 File: `public/script.js`

## 🏗️ Application Architecture

### Class: `DustyScrapper`

#### Constructor
```javascript
constructor() {
    this.currentCategory = 'cars';        // Default category
    this.particles = [];                  // Array to store particle elements
    this.particleCount = 25;             // Number of particles (optimized for performance)
    this.animationId = null;             // Animation frame ID for cleanup
    this.isModalOpen = false;            // Modal state tracking
    this.init();                         // Initialize the application
}
```

## 🔧 Core Methods

### 1. `init()`
**Purpose**: Initializes the application
**Process**:
- Sets up event listeners
- Creates particle effects
- Loads initial data
- Starts particle animation

### 2. `setupEventListeners()`
**Purpose**: Configures all user interaction handlers
**Event Handlers**:
- **Category Selection**: Updates current category and refreshes results
- **Search Button**: Triggers data search
- **Modal Close**: Closes the details modal
- **Outside Modal Click**: Closes modal when clicking outside
- **Escape Key**: Closes modal with keyboard

### 3. `createParticles()`
**Purpose**: Creates animated particle elements
**Process**:
- Generates `particleCount` number of particles
- Positions particles randomly across the screen
- Adds performance classes (glow, fast, slow)
- Applies random animation delays

### 4. `startParticleAnimation()`
**Purpose**: Manages particle animations with performance optimization
**Features**:
- Uses `requestAnimationFrame` for smooth animations
- Only animates visible particles using `isElementInViewport()`
- Adds subtle movement to visible particles
- Stores animation ID for cleanup

### 5. `isElementInViewport(el)`
**Purpose**: Checks if an element is visible in the viewport
**Returns**: boolean - true if element is visible
**Process**: Uses `getBoundingClientRect()` to check element position

### 6. `loadInitialData()`
**Purpose**: Loads data for the current category on page load
**Process**:
- Calls `searchData()` with no price filter
- Shows initial results to user

### 7. `updateResultsTitle()`
**Purpose**: Updates the results title based on selected category
**Process**: Sets `resultsTitle.textContent` with category name

### 8. `searchData()`
**Purpose**: Performs data search based on user input
**Process**:
- Gets selected category and budget input
- Validates budget input (must be positive)
- Shows loading indicator
- Makes API request to backend
- Handles response and errors
- Updates UI with results

### 9. `displayResults(data, totalAvailable, targetPrice)`
**Purpose**: Renders search results in the UI
**Parameters**:
- `data`: Array of items to display
- `totalAvailable`: Total items available in dataset
- `targetPrice`: User's target price
**Process**:
- Updates results count and title
- Clears previous results
- Creates data cards for each item
- Applies staggered animations
- Shows results section

### 10. `createDataCard(item, index)`
**Purpose**: Creates individual result cards
**Parameters**:
- `item`: Data object for the card
- `index`: Position in results array
**Returns**: HTMLDivElement - The created card element
**Features**:
- Formats specifications based on category
- Adds click handler for modal
- Applies staggered animation delays
- Handles different data structures

### 11. `formatCarSpecs(item)`
**Purpose**: Formats car specifications for display
**Returns**: HTML string of formatted specs
**Process**: Maps car properties to readable labels

### 12. `formatPhoneSpecs(item)`
**Purpose**: Formats phone specifications for display
**Returns**: HTML string of formatted specs
**Process**: Maps phone properties to readable labels

### 13. `formatLaptopSpecs(item)`
**Purpose**: Formats laptop specifications for display
**Returns**: HTML string of formatted specs
**Process**: Maps laptop properties to readable labels

### 14. `showItemDetails(item)`
**Purpose**: Displays detailed item information in modal
**Process**:
- Sets modal title
- Generates detailed HTML from item properties
- Shows modal with animations
- Prevents body scrolling

### 15. `closeModal()`
**Purpose**: Closes the details modal
**Process**:
- Hides modal with animations
- Restores body scrolling
- Resets modal state

### 16. `triggerParticleEffect()`
**Purpose**: Creates particle burst effect when data appears
**Process**:
- Creates temporary glowing particles
- Animates them outward
- Removes particles after animation

### 17. `showLoading()`
**Purpose**: Shows loading indicator
**Process**: Removes 'hidden' class from loading element

### 18. `hideLoading()`
**Purpose**: Hides loading indicator
**Process**: Adds 'hidden' class to loading element

### 19. `showError(message)`
**Purpose**: Displays error messages
**Process**:
- Sets error text content
- Shows error display
- Hides loading indicator

### 20. `hideError()`
**Purpose**: Hides error messages
**Process**: Adds 'hidden' class to error display

### 21. `destroy()`
**Purpose**: Cleanup method for performance optimization
**Process**:
- Cancels animation frames
- Removes event listeners
- Called on page unload

## 🛠️ Utility Functions

### `extractPrice(priceString)`
**Purpose**: Frontend price extraction (mirrors backend function)
**Parameters**: `priceString` (string)
**Returns**: number

## ⚡ Performance Optimizations

1. **Reduced Particle Count**: From 50 to 25 particles
2. **Viewport-Based Animation**: Only animates visible particles
3. **RequestAnimationFrame**: Smooth, optimized animations
4. **Staggered Card Animations**: 100ms delays between cards
5. **Cleanup Methods**: Proper resource management

## 🎯 User Interaction Flow

### Search Process
1. User selects category from dropdown
2. User enters target budget
3. User clicks search button
4. Loading indicator appears
5. API request sent to backend
6. Results displayed with animations
7. User can click items for detailed view

### Modal Interaction
1. User clicks on result card
2. Modal opens with item details
3. User can close via:
   - Close button (×)
   - Clicking outside modal
   - Pressing Escape key
4. Modal closes with animations

## 🔧 Technical Implementation Details

### Event Handling
- **Event Delegation**: Efficient event handling for dynamic content
- **Keyboard Support**: Full keyboard navigation support
- **Touch Support**: Mobile-friendly interactions

### Animation System
- **CSS Transitions**: Smooth state changes
- **JavaScript Animations**: Complex particle effects
- **Performance Monitoring**: Viewport-based optimization

### Error Handling
- **API Errors**: Graceful fallback for failed requests
- **Validation**: Input validation before API calls
- **User Feedback**: Clear error messages and loading states

## 📱 Responsive Design Features

### Mobile Optimization
- Touch-friendly interactions
- Responsive grid layouts
- Optimized animations for mobile devices

### Performance Considerations
- Reduced particle count on mobile
- Optimized animations for lower-end devices
- Efficient DOM manipulation
