const express = require('express');
const csv = require('csv-parser');
const fs = require('fs');
const path = require('path');
const cors = require('cors');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.static('public'));

// Store parsed data in memory
let carsData = [];
let phonesData = [];
let laptopsData = [];

// Helper function to parse CSV files
function parseCSV(filePath) {
    return new Promise((resolve, reject) => {
        const results = [];
        fs.createReadStream(filePath)
            .pipe(csv())
            .on('data', (data) => results.push(data))
            .on('end', () => resolve(results))
            .on('error', (error) => reject(error));
    });
}

// Helper function to extract numeric price from string
function extractPrice(priceString) {
    if (!priceString) return 0;
    
    // Remove currency symbols and commas, extract numbers
    const price = priceString.toString().replace(/[^\d,]/g, '').replace(/,/g, '');
    return parseInt(price) || 0;
}

// Helper function to get items closest to target price
function getClosestItems(data, targetPrice, limit = 20) {
    // Always limit to 20 items maximum
    if (!data || data.length === 0) {
        return [];
    }
    
    // If no target price, return first 20 items
    if (!targetPrice || targetPrice <= 0) {
        return data.slice(0, limit);
    }
    
    // Calculate price differences and sort by closest to target
    const itemsWithDiff = data.map(item => {
        let price = 0;
        
        // Extract price based on data type
        if (item.Price) price = extractPrice(item.Price);
        else if (item.price) price = extractPrice(item.price);
        else if (item.price_egp) price = extractPrice(item.price_egp);
        
        return {
            ...item,
            priceValue: price,
            priceDifference: Math.abs(price - targetPrice)
        };
    });
    
    // Filter out items with no price and sort by closest to target
    const validItems = itemsWithDiff
        .filter(item => item.priceValue > 0)
        .sort((a, b) => a.priceDifference - b.priceDifference);
    
    // Return top 20 closest items (or less if not enough valid items)
    return validItems.slice(0, limit);
}

// Load CSV data on server startup
async function loadData() {
    try {
        console.log('Loading CSV data...');
        
        // Load cars data
        carsData = await parseCSV(path.join(__dirname, 'Databases', 'hatla2ee_scraped_data.csv'));
        console.log(`Loaded ${carsData.length} cars`);
        
        // Load phones data
        phonesData = await parseCSV(path.join(__dirname, 'Databases', 'jumia_android_phones.csv'));
        console.log(`Loaded ${phonesData.length} phones`);
        
        // Load laptops data
        laptopsData = await parseCSV(path.join(__dirname, 'Databases', 'Laptops.csv'));
        console.log(`Loaded ${laptopsData.length} laptops`);
        
        console.log('All data loaded successfully!');
    } catch (error) {
        console.error('Error loading CSV data:', error);
    }
}

// API Routes

// Get cars with smart filtering (closest to budget)
app.get('/api/cars', (req, res) => {
    try {
        const targetPrice = req.query.maxPrice ? parseInt(req.query.maxPrice) : null;
        const filteredCars = getClosestItems(carsData, targetPrice, 20);
        
        res.json({
            success: true,
            count: filteredCars.length,
            totalAvailable: carsData.length,
            targetPrice: targetPrice,
            data: filteredCars
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to fetch cars data'
        });
    }
});

// Get phones with smart filtering (closest to budget)
app.get('/api/phones', (req, res) => {
    try {
        const targetPrice = req.query.maxPrice ? parseInt(req.query.maxPrice) : null;
        const filteredPhones = getClosestItems(phonesData, targetPrice, 20);
        
        res.json({
            success: true,
            count: filteredPhones.length,
            totalAvailable: phonesData.length,
            targetPrice: targetPrice,
            data: filteredPhones
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to fetch phones data'
        });
    }
});

// Get laptops with smart filtering (closest to budget)
app.get('/api/laptops', (req, res) => {
    try {
        const targetPrice = req.query.maxPrice ? parseInt(req.query.maxPrice) : null;
        const filteredLaptops = getClosestItems(laptopsData, targetPrice, 20);
        
        res.json({
            success: true,
            count: filteredLaptops.length,
            totalAvailable: laptopsData.length,
            targetPrice: targetPrice,
            data: filteredLaptops
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to fetch laptops data'
        });
    }
});

// Get data summary for all categories
app.get('/api/summary', (req, res) => {
    try {
        res.json({
            success: true,
            summary: {
                cars: carsData.length,
                phones: phonesData.length,
                laptops: laptopsData.length,
                total: carsData.length + phonesData.length + laptopsData.length
            }
        });
    } catch (error) {
        res.status(500).json({
            success: false,
            error: 'Failed to fetch summary data'
        });
    }
});

// Serve the main page
app.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'index.html'));
});

// Start server
app.listen(PORT, async () => {
    console.log(`Server running on port ${PORT}`);
    await loadData();
});

module.exports = app;
