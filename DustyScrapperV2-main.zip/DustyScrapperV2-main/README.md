# Dusty Scrapper V2 - Complete Code Documentation

A full-stack web application for exploring and filtering data from multiple CSV datasets with a modern, responsive UI.

## 📁 Project Structure

```
DustyScrapperV2/
├── server.js              # Backend Express server
├── package.json           # Node.js dependencies and scripts
├── public/                # Frontend files
│   ├── index.html        # Main HTML structure
│   ├── script.js         # Frontend JavaScript application
│   └── styles.css        # Styling (not documented here)
└── datasets/              # CSV data files
    ├── hatla2ee_scraped_data.csv
    ├── jumia_android_phones.csv
    └── Laptops.csv
```

## 🚀 Backend (server.js)

### Overview
The backend is built with Node.js and Express, providing REST API endpoints to serve data from CSV files.

### Dependencies
- **express**: Web framework for creating the server
- **csv-parser**: Library for parsing CSV files to JSON
- **cors**: Middleware for handling Cross-Origin Resource Sharing
- **fs**: Node.js built-in module for file system operations
- **path**: Node.js built-in module for file path operations

### Server Configuration
```javascript
const PORT = 3000;
const app = express();

// Middleware setup
app.use(cors());                    // Enable CORS for all routes
app.use(express.json());            // Parse JSON request bodies
app.use(express.static('public')); // Serve static files from public folder
```

### Data Storage
The server loads CSV data into memory on startup for fast access:
```javascript
let carsData = [];
let phonesData = [];
let laptopsData = [];
```

### Core Functions

#### 1. `parseCSV(filePath)`
**Purpose**: Converts CSV files to JSON objects
**Parameters**: 
- `filePath` (string): Path to the CSV file
**Returns**: Promise<Array> - Array of JSON objects
**Process**:
- Reads the CSV file using Node.js streams
- Parses each row into a JavaScript object
- Handles errors gracefully with try-catch

#### 2. `extractPrice(priceString)`
**Purpose**: Extracts numeric price values from various string formats
**Parameters**: 
- `priceString` (string): Price string that may contain currency symbols, commas, etc.
**Returns**: number - Extracted numeric price
**Process**:
- Removes currency symbols, commas, and spaces
- Converts to number using parseFloat()
- Returns 0 if parsing fails

#### 3. `getClosestItems(data, targetPrice, limit = 20)`
**Purpose**: Filters and sorts data to return items closest to a target price
**Parameters**: 
- `data` (Array): Array of items to filter
- `targetPrice` (number): Target price to find items close to
- `limit` (number): Maximum number of items to return (default: 20)
**Returns**: Array - Filtered and sorted items
**Process**:
- Filters out items with no price (price = 0)
- If no target price, returns first `limit` items
- If target price exists, calculates price difference for each item
- Sorts by price difference (closest first)
- Returns top `limit` items

#### 4. `loadData()`
**Purpose**: Loads all CSV datasets into memory on server startup
**Returns**: Promise<void>
**Process**:
- Calls `parseCSV()` for each dataset file
- Stores parsed data in global arrays
- Logs success/failure for each dataset
- Called automatically when server starts

### API Endpoints

#### 1. `GET /api/cars`
**Purpose**: Returns car data filtered by price
**Query Parameters**: 
- `maxPrice` (optional): Maximum price filter
**Response Format**:
```json
{
  "success": true,
  "count": 20,
  "totalAvailable": 1500,
  "targetPrice": 50000,
  "data": [...]
}
```

#### 2. `GET /api/phones`
**Purpose**: Returns phone data filtered by price
**Query Parameters**: 
- `maxPrice` (optional): Maximum price filter
**Response Format**: Same as cars endpoint

#### 3. `GET /api/laptops`
**Purpose**: Returns laptop data filtered by price
**Query Parameters**: 
- `maxPrice` (optional): Maximum price filter
**Response Format**: Same as cars endpoint

#### 4. `GET /api/summary`
**Purpose**: Returns summary statistics of all loaded datasets
**Response Format**:
```json
{
  "success": true,
  "summary": {
    "cars": 1500,
    "phones": 800,
    "laptops": 1200
  }
}
```

#### 5. `GET /`
**Purpose**: Serves the main HTML page
**Response**: Serves `public/index.html`

### Server Startup
```javascript
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    loadData(); // Load CSV data when server starts
});
```

## 🌐 Frontend (public/index.html)

### HTML Structure Overview
The HTML provides the foundation for the modern UI with semantic elements and proper accessibility.

### Key Sections

#### 1. Document Head
- **Meta tags**: Proper viewport and charset settings
- **Title**: "Dusty Scrapper V2 - Modern Data Explorer"
- **CSS Link**: References `styles.css`

#### 2. Background Elements
```html
<!-- Modern Background -->
<div class="modern-background"></div>

<!-- Modern Typography Elements -->
<div class="modern-text">DATA</div>
<div class="modern-text">EXPLORE</div>
<!-- ... more floating text elements -->
```
**Purpose**: Creates ambient background effects and floating text elements

#### 3. Particles Container
```html
<div class="particles-container"></div>
```
**Purpose**: Container for animated particle effects

#### 4. Main Container
- **Header**: Title and subtitle
- **Controls Section**: Category selector, budget input, search button
- **Loading Indicator**: Spinner and loading text
- **Results Section**: Dynamic content area for search results
- **Error Display**: Error message container

#### 5. Modal Structure
```html
<div id="detailsModal" class="modal hidden">
    <div class="modal-content">
        <div class="modal-header">
            <h3 id="modalTitle" class="modal-title"></h3>
            <span id="modalClose" class="modal-close">&times;</span>
        </div>
        <div class="modal-body">
            <div id="modalDetails"></div>
        </div>
    </div>
</div>
```
**Purpose**: Overlay modal for displaying detailed item information

### Element IDs and Classes
- **Form Elements**: `categorySelect`, `budgetInput`, `searchButton`
- **Display Elements**: `loadingIndicator`, `resultsSection`, `errorDisplay`
- **Modal Elements**: `detailsModal`, `modalTitle`, `modalClose`, `modalDetails`
- **Results Elements**: `resultsTitle`, `resultsCount`, `resultsContainer`

## ⚡ Frontend JavaScript (public/script.js)

### Application Architecture
The frontend uses a class-based architecture with the `DustyScrapper` class managing all functionality.

### Class: `DustyScrapper`

#### Constructor
```javascript
constructor() {
    this.currentCategory = 'cars';        // Default category
    this.particles = [];                  // Array to store particle elements
    this.particleCount = 25;             // Number of particles (optimized for performance)
    this.animationId = null;             // Animation frame ID for cleanup
    this.isModalOpen = false;            // Modal state tracking
    this.init();                         // Initialize the application
}
```

#### Core Methods

##### 1. `init()`
**Purpose**: Initializes the application
**Process**:
- Sets up event listeners
- Creates particle effects
- Loads initial data
- Starts particle animation

##### 2. `setupEventListeners()`
**Purpose**: Configures all user interaction handlers
**Event Handlers**:
- **Category Selection**: Updates current category and refreshes results
- **Search Button**: Triggers data search
- **Modal Close**: Closes the details modal
- **Outside Modal Click**: Closes modal when clicking outside
- **Escape Key**: Closes modal with keyboard

##### 3. `createParticles()`
**Purpose**: Creates animated particle elements
**Process**:
- Generates `particleCount` number of particles
- Positions particles randomly across the screen
- Adds performance classes (glow, fast, slow)
- Applies random animation delays

##### 4. `startParticleAnimation()`
**Purpose**: Manages particle animations with performance optimization
**Features**:
- Uses `requestAnimationFrame` for smooth animations
- Only animates visible particles using `isElementInViewport()`
- Adds subtle movement to visible particles
- Stores animation ID for cleanup

##### 5. `isElementInViewport(el)`
**Purpose**: Checks if an element is visible in the viewport
**Returns**: boolean - true if element is visible
**Process**: Uses `getBoundingClientRect()` to check element position

##### 6. `loadInitialData()`
**Purpose**: Loads data for the current category on page load
**Process**:
- Calls `searchData()` with no price filter
- Shows initial results to user

##### 7. `updateResultsTitle()`
**Purpose**: Updates the results title based on selected category
**Process**: Sets `resultsTitle.textContent` with category name

##### 8. `searchData()`
**Purpose**: Performs data search based on user input
**Process**:
- Gets selected category and budget input
- Validates budget input (must be positive)
- Shows loading indicator
- Makes API request to backend
- Handles response and errors
- Updates UI with results

##### 9. `displayResults(data, totalAvailable, targetPrice)`
**Purpose**: Renders search results in the UI
**Parameters**:
- `data`: Array of items to display
- `totalAvailable`: Total items available in dataset
- `targetPrice`: User's target price
**Process**:
- Updates results count and title
- Clears previous results
- Creates data cards for each item
- Applies staggered animations
- Shows results section

##### 10. `createDataCard(item, index)`
**Purpose**: Creates individual result cards
**Parameters**:
- `item`: Data object for the card
- `index`: Position in results array
**Returns**: HTMLDivElement - The created card element
**Features**:
- Formats specifications based on category
- Adds click handler for modal
- Applies staggered animation delays
- Handles different data structures

##### 11. `formatCarSpecs(item)`
**Purpose**: Formats car specifications for display
**Returns**: HTML string of formatted specs
**Process**: Maps car properties to readable labels

##### 12. `formatPhoneSpecs(item)`
**Purpose**: Formats phone specifications for display
**Returns**: HTML string of formatted specs
**Process**: Maps phone properties to readable labels

##### 13. `formatLaptopSpecs(item)`
**Purpose**: Formats laptop specifications for display
**Returns**: HTML string of formatted specs
**Process**: Maps laptop properties to readable labels

##### 14. `showItemDetails(item)`
**Purpose**: Displays detailed item information in modal
**Process**:
- Sets modal title
- Generates detailed HTML from item properties
- Shows modal with animations
- Prevents body scrolling

##### 15. `closeModal()`
**Purpose**: Closes the details modal
**Process**:
- Hides modal with animations
- Restores body scrolling
- Resets modal state

##### 16. `triggerParticleEffect()`
**Purpose**: Creates particle burst effect when data appears
**Process**:
- Creates temporary glowing particles
- Animates them outward
- Removes particles after animation

##### 17. `showLoading()`
**Purpose**: Shows loading indicator
**Process**: Removes 'hidden' class from loading element

##### 18. `hideLoading()`
**Purpose**: Hides loading indicator
**Process**: Adds 'hidden' class to loading element

##### 19. `showError(message)`
**Purpose**: Displays error messages
**Process**:
- Sets error text content
- Shows error display
- Hides loading indicator

##### 20. `hideError()`
**Purpose**: Hides error messages
**Process**: Adds 'hidden' class to error display

##### 21. `destroy()`
**Purpose**: Cleanup method for performance optimization
**Process**:
- Cancels animation frames
- Removes event listeners
- Called on page unload

### Utility Functions

#### `extractPrice(priceString)`
**Purpose**: Frontend price extraction (mirrors backend function)
**Parameters**: `priceString` (string)
**Returns**: number

### Performance Optimizations
1. **Reduced Particle Count**: From 50 to 25 particles
2. **Viewport-Based Animation**: Only animates visible particles
3. **RequestAnimationFrame**: Smooth, optimized animations
4. **Staggered Card Animations**: 100ms delays between cards
5. **Cleanup Methods**: Proper resource management

## 📦 Package Configuration (package.json)

### Dependencies
- **express**: Web server framework
- **csv-parser**: CSV to JSON conversion
- **cors**: Cross-origin resource sharing

### Dev Dependencies
- **nodemon**: Auto-restart server during development

### Scripts
- **start**: `node server.js` - Production server start
- **dev**: `nodemon server.js` - Development server with auto-restart

## 🔧 Data Structure

### CSV Data Format
Each CSV file contains different data structures:

#### Cars Dataset
- **Source**: `hatla2ee_scraped_data.csv`
- **Fields**: Brand, model, year, mileage, price, etc.

#### Phones Dataset
- **Source**: `jumia_android_phones.csv`
- **Fields**: Brand, model, RAM, storage, price, etc.

#### Laptops Dataset
- **Source**: `Laptops.csv`
- **Fields**: Brand, model, processor, RAM, storage, price, etc.

### API Response Format
```json
{
  "success": true,
  "count": 20,
  "totalAvailable": 1500,
  "targetPrice": 50000,
  "data": [
    {
      "property1": "value1",
      "property2": "value2"
    }
  ]
}
```

## 🚀 Running the Application

### Prerequisites
- Node.js installed
- CSV files in `datasets/` folder

### Installation
```bash
npm install
```

### Development
```bash
npm run dev
```

### Production
```bash
npm start
```

### Access
Open `http://localhost:3000` in your browser

## 🔍 Key Features

1. **Real-time Search**: Instant filtering by category and budget
2. **Smart Filtering**: Shows closest 20 items to target price
3. **Responsive Design**: Works on all device sizes
4. **Performance Optimized**: Efficient animations and data handling
5. **Modal Details**: Click any item for full specifications
6. **Error Handling**: Graceful error display and recovery
7. **Loading States**: Visual feedback during operations
8. **Particle Effects**: Ambient visual enhancements

## 🛠️ Technical Implementation Details

### Backend Architecture
- **Memory-based Storage**: CSV data loaded into arrays for fast access
- **RESTful API**: Clean, predictable endpoints
- **Error Handling**: Comprehensive error catching and logging
- **CORS Support**: Cross-origin requests enabled

### Frontend Architecture
- **Class-based Design**: Organized, maintainable code structure
- **Event-driven**: Responsive user interactions
- **Performance-focused**: Optimized animations and rendering
- **Accessibility**: Keyboard navigation and screen reader support

### Data Flow
1. User selects category and enters budget
2. Frontend sends API request to backend
3. Backend filters data using `getClosestItems()`
4. Results returned as JSON
5. Frontend renders results with animations
6. User can click items for detailed view

This architecture provides a scalable, maintainable foundation for data exploration with excellent user experience and performance characteristics.
