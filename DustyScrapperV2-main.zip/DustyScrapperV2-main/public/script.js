// Main application script for Dusty Scrapper V2

class DustyScrapper {
    constructor() {
        this.currentCategory = 'cars';
        this.particles = [];
        this.particleCount = 25; // Reduced from 40 for better performance
        this.animationId = null;
        this.isModalOpen = false;
        
        this.init();
    }

    init() {
        this.setupEventListeners();
        this.createParticles();
        this.loadInitialData();
        this.startParticleAnimation();
    }

    setupEventListeners() {
        // Category selection
        document.getElementById('categorySelect').addEventListener('change', (e) => {
            this.currentCategory = e.target.value;
            this.updateResultsTitle();
        });

        // Search button
        document.getElementById('searchButton').addEventListener('click', () => {
            this.searchData();
        });

        // Modal close
        document.getElementById('modalClose').addEventListener('click', () => {
            this.closeModal();
        });

        // Close modal when clicking outside
        document.getElementById('detailsModal').addEventListener('click', (e) => {
            if (e.target.id === 'detailsModal') {
                this.closeModal();
            }
        });

        // Keyboard support for modal
        document.addEventListener('keydown', (e) => {
            if (e.key === 'Escape' && this.isModalOpen) {
                this.closeModal();
            }
        });
    }

    createParticles() {
        const container = document.querySelector('.particles-container');
        
        for (let i = 0; i < this.particleCount; i++) {
            const particle = document.createElement('div');
            particle.className = 'particle';
            
            // Random positioning
            particle.style.left = Math.random() * 100 + '%';
            particle.style.top = Math.random() * 100 + '%';
            
            // Random animation delays
            particle.style.animationDelay = Math.random() * 5 + 's';
            
            // Add performance classes
            if (i % 3 === 0) particle.classList.add('glow');
            if (i % 4 === 0) particle.classList.add('fast');
            if (i % 5 === 0) particle.classList.add('slow');
            
            container.appendChild(particle);
            this.particles.push(particle);
        }
    }

    startParticleAnimation() {
        const animate = () => {
            // Only animate particles that are visible
            this.particles.forEach((particle, index) => {
                if (this.isElementInViewport(particle)) {
                    // Add subtle movement for visible particles only
                    if (index % 2 === 0) {
                        const currentLeft = parseFloat(particle.style.left);
                        const newLeft = currentLeft + (Math.random() - 0.5) * 0.5;
                        particle.style.left = Math.max(0, Math.min(100, newLeft)) + '%';
                    }
                }
            });
            
            this.animationId = requestAnimationFrame(animate);
        };
        
        animate();
    }

    isElementInViewport(el) {
        const rect = el.getBoundingClientRect();
        return (
            rect.top >= 0 &&
            rect.left >= 0 &&
            rect.bottom <= (window.innerHeight || document.documentElement.clientHeight) &&
            rect.right <= (window.innerWidth || document.documentElement.clientWidth)
        );
    }

    loadInitialData() {
        this.updateResultsTitle();
    }

    updateResultsTitle() {
        const titles = {
            cars: '🚗 Car Explorations',
            phones: '📱 Phone Discoveries',
            laptops: '💻 Laptop Treasures'
        };
        
        const resultsTitle = document.getElementById('resultsTitle');
        if (resultsTitle) {
            resultsTitle.textContent = titles[this.currentCategory] || 'Results';
        }
    }

    async searchData() {
        const budgetInput = document.getElementById('budgetInput');
        const maxPrice = budgetInput.value ? parseInt(budgetInput.value) : '';
        
        if (maxPrice && maxPrice < 0) {
            this.showError('Please enter a valid positive number for budget');
            return;
        }

        this.showLoading();
        this.hideError();

        try {
            const queryParams = maxPrice ? `?maxPrice=${maxPrice}` : '';
            const response = await fetch(`/api/${this.currentCategory}${queryParams}`);
            
            if (!response.ok) {
                throw new Error(`HTTP error! status: ${response.status}`);
            }
            
            const result = await response.json();
            
            if (result.success) {
                this.displayResults(result.data, result.totalAvailable, result.targetPrice);
                this.triggerParticleEffect();
            } else {
                throw new Error(result.error || 'Failed to fetch data');
            }
        } catch (error) {
            console.error('Search error:', error);
            this.showError(`Failed to search: ${error.message}`);
        } finally {
            this.hideLoading();
        }
    }

    displayResults(data, totalAvailable, targetPrice) {
        const resultsSection = document.getElementById('resultsSection');
        const resultsContainer = document.getElementById('resultsContainer');
        const resultsCount = document.getElementById('resultsCount');
        
        // Update results count with cave-themed message
        let countMessage = `Found ${data.length} items in the depths`;
        if (targetPrice) {
            countMessage += ` closest to ${targetPrice.toLocaleString()} EGP`;
        }
        countMessage += ` (showing top 20 of ${totalAvailable.toLocaleString()} total items)`;
        
        resultsCount.innerHTML = `
            <span class="cave-info">${countMessage}</span>
            <br><small class="cave-note">💡 Only the 20 closest matches to your budget are shown</small>
        `;
        
        // Clear previous results
        resultsContainer.innerHTML = '';
        
        // Create cards for each item with click handlers
        data.forEach((item, index) => {
            const card = this.createDataCard(item, index);
            resultsContainer.appendChild(card);
        });
        
        // Show results section
        resultsSection.classList.remove('hidden');
        
        // Animate cards appearance with cave effect
        setTimeout(() => {
            const cards = resultsContainer.querySelectorAll('.data-card');
            cards.forEach((card, index) => {
                setTimeout(() => {
                    card.classList.add('animate-in');
                }, index * 100); // Reduced delay for better performance
            });
        }, 100);
    }

    createDataCard(item, index) {
        const card = document.createElement('div');
        card.className = 'data-card';
        card.style.animationDelay = `${index * 0.1}s`;
        
        let specs = '';
        switch (this.currentCategory) {
            case 'cars':
                specs = this.formatCarSpecs(item);
                break;
            case 'phones':
                specs = this.formatPhoneSpecs(item);
                break;
            case 'laptops':
                specs = this.formatLaptopSpecs(item);
                break;
        }
        
        card.innerHTML = `
            <div class="card-header">
                <h3 class="card-title">${this.getItemTitle(item)}</h3>
                <div class="card-price">${this.getItemPrice(item)}</div>
            </div>
            <div class="card-specs">
                ${specs}
            </div>
            <div style="text-align: center; margin-top: 15px; color: #a0522d; font-size: 0.9rem;">
                💡 Click to see full details
            </div>
        `;
        
        // Add click event listener directly to the card
        card.addEventListener('click', (e) => {
            console.log('Card clicked!', item);
            this.showItemDetails(item);
        });
        
        return card;
    }

    getItemTitle(item) {
        switch (this.currentCategory) {
            case 'cars':
                return item.Brand && item.Model ? `${item.Brand} ${item.Model}` : item.Brand || item.Model || 'Unknown Car';
            case 'phones':
                return item.name || item.brand || 'Unknown Phone';
            case 'laptops':
                return item.name || item.brand || 'Unknown Laptop';
            default:
                return 'Unknown Item';
        }
    }

    getItemPrice(item) {
        let price = 0;
        if (item.Price) price = this.extractPrice(item.Price);
        else if (item.price) price = this.extractPrice(item.price);
        else if (item.price_egp) price = this.extractPrice(item.price_egp);
        
        return price > 0 ? `${price.toLocaleString()} EGP` : 'Price not available';
    }

    formatCarSpecs(item) {
        const specs = [
            { label: 'Brand', value: item.Brand },
            { label: 'Model', value: item.Model },
            { label: 'Year', value: item.Year },
            { label: 'Mileage', value: item.Mileage },
            { label: 'Engine', value: item.Engine },
            { label: 'Transmission', value: item.Transmission },
            { label: 'Fuel Type', value: item['Fuel Type'] },
            { label: 'Color', value: item.Color }
        ];
        
        return this.renderSpecs(specs, item);
    }

    formatPhoneSpecs(item) {
        const specs = [
            { label: 'Brand', value: item.brand },
            { label: 'Model', value: item.model },
            { label: 'Storage', value: item.storage },
            { label: 'RAM', value: item.ram },
            { label: 'Screen', value: item.screen },
            { label: 'Camera', value: item.camera },
            { label: 'Battery', value: item.battery }
        ];
        
        return this.renderSpecs(specs, item);
    }

    formatLaptopSpecs(item) {
        const specs = [
            { label: 'Brand', value: item.brand },
            { label: 'Processor', value: item.processor },
            { label: 'RAM', value: item.ram },
            { label: 'Storage', value: item.storage },
            { label: 'Graphics', value: item.graphics },
            { label: 'Screen', value: item.screen },
            { label: 'OS', value: item.os }
        ];
        
        return this.renderSpecs(specs, item);
    }

    renderSpecs(specs, item) {
        return specs
            .filter(spec => spec.value && spec.value.toString().trim() !== '')
            .map(spec => `
                <div class="spec-item">
                    <span class="spec-label">${spec.label}:</span>
                    <span class="spec-value">${spec.value}</span>
                </div>
            `).join('');
    }

    showItemDetails(item) {
        if (this.isModalOpen) return;
        
        this.isModalOpen = true;
        const modal = document.getElementById('detailsModal');
        const modalTitle = document.getElementById('modalTitle');
        const modalDetails = document.getElementById('modalDetails');
        
        // Set modal title
        modalTitle.textContent = this.getItemTitle(item);
        
        // Generate detailed specifications
        let detailsHTML = '';
        
        // Add price at the top
        detailsHTML += `
            <div class="modal-detail-item" style="background: rgba(210, 105, 30, 0.2); border-radius: 8px; margin-bottom: 20px;">
                <span class="modal-detail-label">💰 Price:</span>
                <span class="modal-detail-value" style="color: #32cd32; font-size: 1.2rem; font-weight: bold;">
                    ${this.getItemPrice(item)}
                </span>
            </div>
        `;
        
        // Add all available specifications
        Object.entries(item).forEach(([key, value]) => {
            if (value && value.toString().trim() !== '' && key.toLowerCase() !== 'price') {
                const label = key.replace(/([A-Z])/g, ' $1').replace(/^./, str => str.toUpperCase());
                let displayValue = value;
                
                // Check if it's a URL
                if (typeof value === 'string' && (value.startsWith('http://') || value.startsWith('https://'))) {
                    displayValue = `<a href="${value}" target="_blank" class="cave-link">${value}</a>`;
                }
                
                detailsHTML += `
                    <div class="modal-detail-item">
                        <span class="modal-detail-label">${label}:</span>
                        <span class="modal-detail-value">${displayValue}</span>
                    </div>
                `;
            }
        });
        
        modalDetails.innerHTML = detailsHTML;
        
        // Show modal with animation
        modal.classList.remove('hidden');
        document.body.style.overflow = 'hidden';
        
        // Force modal to be visible and interactive
        modal.style.display = 'flex';
        modal.style.pointerEvents = 'auto';
        
        // Add entrance animation
        setTimeout(() => {
            const modalContent = modal.querySelector('.modal-content');
            if (modalContent) {
                modalContent.style.transform = 'scale(1)';
                modalContent.style.opacity = '1';
            }
        }, 10);
    }

    closeModal() {
        if (!this.isModalOpen) return;
        
        this.isModalOpen = false;
        const modal = document.getElementById('detailsModal');
        const modalContent = modal.querySelector('.modal-content');
        
        // Add exit animation
        if (modalContent) {
            modalContent.style.transform = 'scale(0.9)';
            modalContent.style.opacity = '0';
        }
        
        setTimeout(() => {
            modal.classList.add('hidden');
            modal.style.display = 'none';
            modal.style.pointerEvents = 'none';
            if (modalContent) {
                modalContent.style.transform = 'scale(1)';
                modalContent.style.opacity = '1';
            }
            document.body.style.overflow = 'auto';
        }, 200);
    }

    triggerParticleEffect() {
        // Optimized particle effect - only animate visible particles
        const visibleParticles = this.particles.filter(particle => 
            this.isElementInViewport(particle)
        );
        
        visibleParticles.forEach((particle, index) => {
            setTimeout(() => {
                particle.classList.add('glow');
                setTimeout(() => {
                    particle.classList.remove('glow');
                }, 1000);
            }, index * 50);
        });
    }

    showLoading() {
        document.getElementById('loadingIndicator').classList.remove('hidden');
    }

    hideLoading() {
        document.getElementById('loadingIndicator').classList.add('hidden');
    }

    showError(message) {
        const errorDisplay = document.getElementById('errorDisplay');
        const errorText = errorDisplay.querySelector('.error-text');
        errorText.textContent = message;
        errorDisplay.classList.remove('hidden');
    }

    hideError() {
        document.getElementById('errorDisplay').classList.add('hidden');
    }

    extractPrice(priceString) {
        if (!priceString) return 0;
        
        const priceMatch = priceString.toString().match(/[\d,]+/);
        if (priceMatch) {
            return parseInt(priceMatch[0].replace(/,/g, ''));
        }
        return 0;
    }

    // Cleanup method for better performance
    destroy() {
        if (this.animationId) {
            cancelAnimationFrame(this.animationId);
        }
        this.particles = [];
    }
}

// Initialize the application when DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    window.dustyScrapper = new DustyScrapper();
});

// Cleanup on page unload
window.addEventListener('beforeunload', () => {
    if (window.dustyScrapper) {
        window.dustyScrapper.destroy();
    }
});
