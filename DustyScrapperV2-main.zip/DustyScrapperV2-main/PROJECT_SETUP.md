# Project Setup & Configuration - Dusty Scrapper V2

## 📁 Project Structure

```
DustyScrapperV2/
├── server.js              # Backend Express server
├── package.json           # Node.js dependencies and scripts
├── public/                # Frontend files
│   ├── index.html        # Main HTML structure
│   ├── script.js         # Frontend JavaScript application
│   └── styles.css        # Styling (not documented here)
└── datasets/              # CSV data files
    ├── hatla2ee_scraped_data.csv
    ├── jumia_android_phones.csv
    └── Laptops.csv
```

## 📦 Package Configuration

### File: `package.json`

#### Basic Information
```json
{
  "name": "dusty-scrapper-v2",
  "version": "1.0.0",
  "description": "Full-stack web application for exploring CSV datasets",
  "main": "server.js",
  "scripts": {
    "start": "node server.js",
    "dev": "nodemon server.js"
  }
}
```

#### Dependencies
- **express**: Web server framework for creating REST API endpoints
- **csv-parser**: Library for parsing CSV files to JSON format
- **cors**: Middleware for handling Cross-Origin Resource Sharing

#### Dev Dependencies
- **nodemon**: Auto-restart server during development for faster iteration

#### Scripts
- **start**: `node server.js` - Production server start
- **dev**: `nodemon server.js` - Development server with auto-restart

## 🚀 Installation & Setup

### Prerequisites
- **Node.js**: Version 14 or higher recommended
- **npm**: Node package manager (comes with Node.js)
- **CSV Files**: Place your dataset files in the `datasets/` folder

### Step-by-Step Installation

#### 1. Clone or Download Project
```bash
# If using git
git clone <repository-url>
cd DustyScrapperV2

# Or download and extract ZIP file
# Navigate to project directory
```

#### 2. Install Dependencies
```bash
npm install
```

#### 3. Prepare Data Files
Ensure your CSV files are in the `datasets/` folder:
- `hatla2ee_scraped_data.csv` - Car data
- `jumia_android_phones.csv` - Phone data  
- `Laptops.csv` - Laptop data

#### 4. Start the Application

**Development Mode (with auto-restart):**
```bash
npm run dev
```

**Production Mode:**
```bash
npm start
```

#### 5. Access the Application
Open your browser and navigate to:
```
http://localhost:3000
```

## 🔧 Configuration Options

### Server Configuration
The server runs on port 3000 by default. To change this:

**Option 1: Environment Variable**
```bash
# Set environment variable
export PORT=8080
npm start

# Or on Windows
set PORT=8080
npm start
```

**Option 2: Modify server.js**
```javascript
const PORT = process.env.PORT || 8080; // Change 3000 to your preferred port
```

### CORS Configuration
The server includes CORS middleware for cross-origin requests:

```javascript
app.use(cors()); // Allows all origins by default
```

To restrict CORS to specific domains:
```javascript
app.use(cors({
    origin: ['http://localhost:3000', 'https://yoursite.com']
}));
```

## 📊 Data File Requirements

### CSV Format Requirements
- **Header Row**: First row should contain column names
- **Comma Separated**: Values separated by commas
- **UTF-8 Encoding**: Ensure proper character encoding
- **Consistent Structure**: All rows should have the same number of columns

### Required Fields
While the application is flexible, these fields are recommended:

#### Cars Dataset
- Brand/Manufacturer
- Model
- Year
- Price
- Mileage
- Additional specifications

#### Phones Dataset
- Brand/Manufacturer
- Model
- RAM
- Storage
- Price
- Additional specifications

#### Laptops Dataset
- Brand/Manufacturer
- Model
- Processor
- RAM
- Storage
- Price
- Additional specifications

## 🛠️ Development Workflow

### Development Mode
```bash
npm run dev
```
**Features:**
- Auto-restart on file changes
- Real-time error reporting
- Faster development iteration

### Production Mode
```bash
npm start
```
**Features:**
- Optimized performance
- No auto-restart
- Production-ready logging

### Debugging
```bash
# Run with Node.js debugger
node --inspect server.js

# Or with nodemon
nodemon --inspect server.js
```

## 🔍 Troubleshooting

### Common Issues

#### Port Already in Use
```bash
# Error: EADDRINUSE
# Solution: Kill existing process or change port
lsof -ti:3000 | xargs kill -9  # On macOS/Linux
taskkill /F /IM node.exe        # On Windows
```

#### CSV Parsing Errors
- Check file encoding (should be UTF-8)
- Verify CSV format (proper comma separation)
- Ensure header row exists
- Check for special characters in data

#### Module Not Found Errors
```bash
# Reinstall dependencies
rm -rf node_modules package-lock.json
npm install
```

#### CORS Issues
- Verify CORS middleware is enabled
- Check browser console for CORS errors
- Ensure frontend and backend are on same origin during development

### Performance Issues

#### Large CSV Files
- Consider splitting very large files
- Monitor memory usage
- Use streaming for extremely large datasets

#### Slow Search Performance
- Verify data is loaded into memory
- Check for inefficient filtering logic
- Monitor API response times

## 🚀 Deployment

### Environment Variables
```bash
# Production environment variables
NODE_ENV=production
PORT=8080
```

### Process Management
**Using PM2:**
```bash
# Install PM2
npm install -g pm2

# Start application
pm2 start server.js --name "dusty-scrapper"

# Monitor
pm2 monit

# Restart
pm2 restart dusty-scrapper
```

**Using Docker:**
```dockerfile
FROM node:16-alpine
WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production
COPY . .
EXPOSE 3000
CMD ["npm", "start"]
```

### Reverse Proxy (Nginx)
```nginx
server {
    listen 80;
    server_name yourdomain.com;
    
    location / {
        proxy_pass http://localhost:3000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection 'upgrade';
        proxy_set_header Host $host;
        proxy_cache_bypass $http_upgrade;
    }
}
```

## 📚 Additional Resources

### Documentation Files
- `BACKEND_DOCUMENTATION.md` - Backend code documentation
- `FRONTEND_JAVASCRIPT.md` - Frontend JavaScript documentation
- `HTML_STRUCTURE.md` - HTML structure documentation
- `README.md` - General project overview

### Useful Commands
```bash
# Check Node.js version
node --version

# Check npm version
npm --version

# List installed packages
npm list

# Update dependencies
npm update

# Run tests (if configured)
npm test

# Build for production (if configured)
npm run build
```

### Development Tools
- **VS Code**: Recommended editor with Node.js extensions
- **Postman**: API testing tool
- **Chrome DevTools**: Frontend debugging
- **Node.js Inspector**: Backend debugging

This setup provides a solid foundation for development, testing, and deployment of the Dusty Scrapper V2 application.
