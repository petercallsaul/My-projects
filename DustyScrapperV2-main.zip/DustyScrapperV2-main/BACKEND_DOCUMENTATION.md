# Backend Documentation - Dusty Scrapper V2

## 🚀 Overview
The backend is built with Node.js and Express, providing REST API endpoints to serve data from CSV files.

## 📁 File: `server.js`

### Dependencies
- **express**: Web framework for creating the server
- **csv-parser**: Library for parsing CSV files to JSON
- **cors**: Middleware for handling Cross-Origin Resource Sharing
- **fs**: Node.js built-in module for file system operations
- **path**: Node.js built-in module for file path operations

### Server Configuration
```javascript
const PORT = 3000;
const app = express();

// Middleware setup
app.use(cors());                    // Enable CORS for all routes
app.use(express.json());            // Parse JSON request bodies
app.use(express.static('public')); // Serve static files from public folder
```

### Data Storage
The server loads CSV data into memory on startup for fast access:
```javascript
let carsData = [];
let phonesData = [];
let laptopsData = [];
```

## 🔧 Core Functions

### 1. `parseCSV(filePath)`
**Purpose**: Converts CSV files to JSON objects
**Parameters**: 
- `filePath` (string): Path to the CSV file
**Returns**: Promise<Array> - Array of JSON objects
**Process**:
- Reads the CSV file using Node.js streams
- Parses each row into a JavaScript object
- Handles errors gracefully with try-catch

### 2. `extractPrice(priceString)`
**Purpose**: Extracts numeric price values from various string formats
**Parameters**: 
- `priceString` (string): Price string that may contain currency symbols, commas, etc.
**Returns**: number - Extracted numeric price
**Process**:
- Removes currency symbols, commas, and spaces
- Converts to number using parseFloat()
- Returns 0 if parsing fails

### 3. `getClosestItems(data, targetPrice, limit = 20)`
**Purpose**: Filters and sorts data to return items closest to a target price
**Parameters**: 
- `data` (Array): Array of items to filter
- `targetPrice` (number): Target price to find items close to
- `limit` (number): Maximum number of items to return (default: 20)
**Returns**: Array - Filtered and sorted items
**Process**:
- Filters out items with no price (price = 0)
- If no target price, returns first `limit` items
- If target price exists, calculates price difference for each item
- Sorts by price difference (closest first)
- Returns top `limit` items

### 4. `loadData()`
**Purpose**: Loads all CSV datasets into memory on server startup
**Returns**: Promise<void>
**Process**:
- Calls `parseCSV()` for each dataset file
- Stores parsed data in global arrays
- Logs success/failure for each dataset
- Called automatically when server starts

## 🌐 API Endpoints

### 1. `GET /api/cars`
**Purpose**: Returns car data filtered by price
**Query Parameters**: 
- `maxPrice` (optional): Maximum price filter
**Response Format**:
```json
{
  "success": true,
  "count": 20,
  "totalAvailable": 1500,
  "targetPrice": 50000,
  "data": [...]
}
```

### 2. `GET /api/phones`
**Purpose**: Returns phone data filtered by price
**Query Parameters**: 
- `maxPrice` (optional): Maximum price filter
**Response Format**: Same as cars endpoint

### 3. `GET /api/laptops`
**Purpose**: Returns laptop data filtered by price
**Query Parameters**: 
- `maxPrice` (optional): Maximum price filter
**Response Format**: Same as cars endpoint

### 4. `GET /api/summary`
**Purpose**: Returns summary statistics of all loaded datasets
**Response Format**:
```json
{
  "success": true,
  "summary": {
    "cars": 1500,
    "phones": 800,
    "laptops": 1200
  }
}
```

### 5. `GET /`
**Purpose**: Serves the main HTML page
**Response**: Serves `public/index.html`

## 🚀 Server Startup
```javascript
app.listen(PORT, () => {
    console.log(`Server running on port ${PORT}`);
    loadData(); // Load CSV data when server starts
});
```

## 🔧 Data Structure

### CSV Data Format
Each CSV file contains different data structures:

#### Cars Dataset
- **Source**: `hatla2ee_scraped_data.csv`
- **Fields**: Brand, model, year, mileage, price, etc.

#### Phones Dataset
- **Source**: `jumia_android_phones.csv`
- **Fields**: Brand, model, RAM, storage, price, etc.

#### Laptops Dataset
- **Source**: `Laptops.csv`
- **Fields**: Brand, model, processor, RAM, storage, price, etc.

### API Response Format
```json
{
  "success": true,
  "count": 20,
  "totalAvailable": 1500,
  "targetPrice": 50000,
  "data": [
    {
      "property1": "value1",
      "property2": "value2"
    }
  ]
}
```

## 🛠️ Technical Implementation Details

### Backend Architecture
- **Memory-based Storage**: CSV data loaded into arrays for fast access
- **RESTful API**: Clean, predictable endpoints
- **Error Handling**: Comprehensive error catching and logging
- **CORS Support**: Cross-origin requests enabled

### Performance Considerations
- **Stream-based CSV parsing**: Efficient memory usage for large files
- **In-memory data storage**: Fast response times for API calls
- **Optimized filtering**: Smart algorithm for finding closest price matches
