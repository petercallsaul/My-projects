module.exports = {
  OPENWEATHER_API_KEY: '564e502499eeb93b4ab8a41195ccf3d4', // Yes i didn't forget to delete it
  PORT: process.env.PORT || 3000
};

