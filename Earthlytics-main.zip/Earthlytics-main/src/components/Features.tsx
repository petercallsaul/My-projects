import { Map, Database, Sparkles } from "lucide-react";
import { Card } from "./ui/card";
import spaceStarfield from "@/assets/space-starfield.jpg";

const Features = () => {
  const features = [
    {
      icon: Map,
      title: "Explore the Map",
      description: "Navigate through the interactive map powered by NASA and global datasets. Zoom into any region of interest, or use the search bar to quickly find locations worldwide."
    },
    {
      icon: Database,
      title: "Discover the Data",
      description: "Once you choose a region, the app instantly generates a clear, AI-driven summary. View key environmental insights such as soil type, pollution levels, vegetation cover, and natural resources."
    },
    {
      icon: Sparkles,
      title: "Get Smart Guidance with AI",
      description: "Go beyond the data with AI analysis. Receive tailored suggestions on the most suitable urban designs, building types, or activities for the area."
    }
  ];

  return (
    <section className="py-24 bg-background">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Features</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Powerful tools to help you make informed decisions about urban development
          </p>
        </div>

        {/* Feature image */}
        <div className="mb-16 max-w-5xl mx-auto">
          <div className="relative rounded-2xl overflow-hidden shadow-[var(--shadow-elegant)] border border-primary/20">
            <img 
              src={spaceStarfield} 
              alt="Space observation technology for urban planning" 
              className="w-full h-96 object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-background/90 to-transparent" />
            <div className="absolute inset-0 flex items-center justify-center">
              <div className="text-center z-10">
                <Sparkles className="h-16 w-16 text-primary mx-auto mb-4 drop-shadow-[0_0_20px_hsl(var(--primary))]" />
                <p className="text-2xl font-bold text-foreground">Powered by NASA Earth Observation</p>
              </div>
            </div>
          </div>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-6xl mx-auto">
          {features.map((feature, index) => (
            <Card 
              key={index}
              className="p-8 hover:shadow-[var(--shadow-elegant)] transition-all hover:-translate-y-1 border-primary/20 bg-card/50 backdrop-blur-sm"
            >
              <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-2xl flex items-center justify-center mb-6 shadow-[var(--glow-grey)]">
                <feature.icon className="h-8 w-8 text-primary-foreground" />
              </div>
              <h3 className="text-2xl font-bold mb-4">{feature.title}</h3>
              <p className="text-muted-foreground leading-relaxed">
                {feature.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Features;
