import { Card } from "../ui/card";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "../ui/table";
import { Badge } from "../ui/badge";

const DataTable = () => {
  const sampleData = [
    { parameter: "Soil Type", value: "Coming Soon", status: "pending" },
    { parameter: "Pollution Level", value: "Coming Soon", status: "pending" },
    { parameter: "Vegetation Index", value: "Coming Soon", status: "pending" },
    { parameter: "Natural Resources", value: "Coming Soon", status: "pending" },
    { parameter: "Population Density", value: "Coming Soon", status: "pending" }
  ];

  return (
    <Card className="p-6">
      <h3 className="text-xl font-bold mb-4">Environmental Data Summary</h3>
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Parameter</TableHead>
            <TableHead>Value</TableHead>
            <TableHead>Status</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {sampleData.map((row, index) => (
            <TableRow key={index}>
              <TableCell className="font-medium">{row.parameter}</TableCell>
              <TableCell>{row.value}</TableCell>
              <TableCell>
                <Badge variant="outline">Integration Pending</Badge>
              </TableCell>
            </TableRow>
          ))}
        </TableBody>
      </Table>
    </Card>
  );
};

export default DataTable;
