import { Card } from "../ui/card";
import { Droplets, Wind, TreePine, Thermometer } from "lucide-react";

const DataCards = () => {
  const metrics = [
    {
      icon: Droplets,
      label: "Water Quality",
      value: "Coming Soon",
      color: "from-blue-500 to-cyan-500"
    },
    {
      icon: Wind,
      label: "Air Quality",
      value: "Coming Soon",
      color: "from-primary to-secondary"
    },
    {
      icon: TreePine,
      label: "Vegetation Cover",
      value: "Coming Soon",
      color: "from-green-500 to-emerald-500"
    },
    {
      icon: Thermometer,
      label: "Temperature",
      value: "Coming Soon",
      color: "from-orange-500 to-red-500"
    }
  ];

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {metrics.map((metric, index) => (
        <Card key={index} className="p-6 hover:shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 border-primary/20">
          <div className={`w-12 h-12 bg-gradient-to-br ${metric.color} rounded-xl flex items-center justify-center mb-4 shadow-[var(--glow-cyan)]`}>
            <metric.icon className="h-6 w-6 text-white" />
          </div>
          <h3 className="text-sm font-medium text-muted-foreground mb-1">{metric.label}</h3>
          <p className="text-2xl font-bold text-foreground">{metric.value}</p>
        </Card>
      ))}
    </div>
  );
};

export default DataCards;
