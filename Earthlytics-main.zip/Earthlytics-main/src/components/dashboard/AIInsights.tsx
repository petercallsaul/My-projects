import { Card } from "../ui/card";
import { Sparkles, TrendingUp, AlertCircle, CheckCircle } from "lucide-react";
import { Badge } from "../ui/badge";

const AIInsights = () => {
  const insights = [
    {
      icon: CheckCircle,
      title: "Urban Planning Analysis",
      description: "AI-powered recommendations for sustainable development",
      status: "pending",
      color: "text-green-500"
    },
    {
      icon: TrendingUp,
      title: "Growth Predictions",
      description: "Climate-adjusted urban growth forecasts",
      status: "pending",
      color: "text-blue-500"
    },
    {
      icon: AlertCircle,
      title: "Risk Assessment",
      description: "Environmental and climate risk analysis",
      status: "pending",
      color: "text-orange-500"
    }
  ];

  return (
    <Card className="p-6 border-primary/20">
      <div className="flex items-center gap-2 mb-6">
        <Sparkles className="h-6 w-6 text-primary" />
        <h3 className="text-xl font-bold">AI Insights</h3>
        <Badge variant="secondary" className="ml-auto">Beta</Badge>
      </div>

      <div className="space-y-4">
        {insights.map((insight, index) => (
          <div 
            key={index}
            className="p-4 rounded-lg border border-primary/10 bg-muted/30 hover:bg-muted/50 transition-colors"
          >
            <div className="flex items-start gap-3">
              <insight.icon className={`h-5 w-5 mt-0.5 ${insight.color}`} />
              <div className="flex-1">
                <h4 className="font-semibold mb-1 text-foreground">{insight.title}</h4>
                <p className="text-sm text-muted-foreground">{insight.description}</p>
                <Badge variant="outline" className="mt-2 text-xs">
                  Integration Pending
                </Badge>
              </div>
            </div>
          </div>
        ))}
      </div>
    </Card>
  );
};

export default AIInsights;
