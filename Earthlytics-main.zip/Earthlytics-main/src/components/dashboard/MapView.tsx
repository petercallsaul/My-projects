import "leaflet/dist/leaflet.css";
import { Card } from "../ui/card";
import { MapContainer, TileLayer, useMap } from "react-leaflet";
import { useEffect } from "react";
import L from "leaflet";
import "leaflet.heat";

// Sample heat data points [lat, lng, intensity]
const heatData = [
  [37.7749, -122.4194, 0.8],
  [37.7849, -122.4094, 0.9],
  [37.7649, -122.4294, 0.7],
  [40.7128, -74.0060, 0.6],
  [40.7228, -74.0160, 0.8],
  [40.7028, -73.9960, 0.5],
  [51.5074, -0.1278, 0.7],
  [51.5174, -0.1178, 0.9],
  [51.4974, -0.1378, 0.6],
  [35.6762, 139.6503, 0.8],
  [35.6862, 139.6603, 0.7],
  [35.6662, 139.6403, 0.9],
];

const HeatmapLayer = () => {
  const map = useMap();

  useEffect(() => {
    if (!map) return;

    // @ts-ignore - leaflet.heat types
    const heatLayer = L.heatLayer(heatData, {
      radius: 25,
      blur: 15,
      maxZoom: 17,
      max: 1.0,
      gradient: {
        0.0: '#1a1a2e',
        0.2: '#16213e',
        0.4: '#0f3460',
        0.6: '#533483',
        0.8: '#e94560',
        1.0: '#ff6b6b'
      }
    }).addTo(map);

    return () => {
      map.removeLayer(heatLayer);
    };
  }, [map]);

  return null;
};

const MapView = () => {
  return (
    <Card className="p-6 h-full border-primary/20 bg-card/50 backdrop-blur-sm">
      <div className="mb-4">
        <h3 className="text-xl font-bold text-foreground">NASA Data Heatmap</h3>
        <p className="text-sm text-muted-foreground mt-1">
          Interactive visualization of Earth observation data intensity
        </p>
      </div>
      
      <div className="rounded-lg overflow-hidden border border-primary/20 h-[500px]">
        <MapContainer
          center={[37.7749, -122.4194]}
          zoom={3}
          style={{ height: "100%", width: "100%" }}
          className="z-0"
        >
          <TileLayer
            url="https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png"
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>'
          />
          <HeatmapLayer />
        </MapContainer>
      </div>

      <div className="mt-4 flex gap-4 flex-wrap">
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-[#1a1a2e]" />
          <span className="text-xs text-muted-foreground">Low Intensity</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-[#533483]" />
          <span className="text-xs text-muted-foreground">Medium Intensity</span>
        </div>
        <div className="flex items-center gap-2">
          <div className="w-4 h-4 rounded-full bg-[#ff6b6b]" />
          <span className="text-xs text-muted-foreground">High Intensity</span>
        </div>
      </div>
    </Card>
  );
};

export default MapView;
