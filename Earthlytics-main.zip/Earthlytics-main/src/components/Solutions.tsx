import { BarChart3, Trees, Hospital, AlertTriangle } from "lucide-react";
import { Card } from "./ui/card";

const Solutions = () => {
  const solutions = [
    {
      icon: BarChart3,
      title: "Urban Resilience Dashboard",
      description: "A centralized online tool that integrates NASA datasets to help planners, leaders, and citizens visualize urban vulnerabilities and opportunities."
    },
    {
      icon: Trees,
      title: "Greenspace Mapping",
      description: "Identifies communities with limited access to parks or vegetation and provides data-backed strategies for expanding urban greenery."
    },
    {
      icon: Hospital,
      title: "Healthcare Accessibility Planner",
      description: "Pinpoints areas lacking hospitals or clinics and overlays population density and climate risk to support better resource allocation."
    },
    {
      icon: AlertTriangle,
      title: "Pollution Hotspot Tracker",
      description: "Uses air and water quality data to highlight industrial impacts and recommend pollution control strategies."
    }
  ];

  return (
    <section className="py-24 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Solutions of Action</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto mb-6" />
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Comprehensive tools to address urban challenges and promote sustainable development
          </p>
        </div>

        <div className="grid md:grid-cols-2 lg:grid-cols-4 gap-6 max-w-7xl mx-auto">
          {solutions.map((solution, index) => (
            <Card 
              key={index}
              className="p-6 hover:shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 border-primary/20 bg-card/50 backdrop-blur-sm"
            >
              <div className="w-12 h-12 bg-gradient-to-br from-primary to-secondary rounded-xl flex items-center justify-center mb-4 shadow-[var(--glow-grey)]">
                <solution.icon className="h-6 w-6 text-primary-foreground" />
              </div>
              <h3 className="text-lg font-bold mb-3">{solution.title}</h3>
              <p className="text-sm text-muted-foreground leading-relaxed">
                {solution.description}
              </p>
            </Card>
          ))}
        </div>
      </div>
    </section>
  );
};

export default Solutions;
