import { Button } from "./ui/button";
import { Link } from "react-router-dom";
import { ArrowRight, Sparkles } from "lucide-react";
import spaceHero from "@/assets/space-hero.jpg";

const Hero = () => {
  return (
    <section className="relative min-h-screen flex items-center justify-center overflow-hidden">
      {/* Space nebula background */}
      <div className="absolute inset-0 bg-background">
        <img 
          src={spaceHero} 
          alt="Space nebula background" 
          className="w-full h-full object-cover opacity-50"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/40 to-background" />
      </div>
      
      {/* Animated cosmic glow effects */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-1/3 left-1/2 -translate-x-1/2 w-[600px] h-[600px] bg-primary/30 rounded-full blur-[120px] animate-pulse" style={{ boxShadow: 'var(--glow-grey)' }} />
        <div className="absolute top-1/2 left-1/4 w-80 h-80 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-1/3 right-1/4 w-80 h-80 bg-secondary/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1.5s' }} />
        <div className="absolute top-1/4 right-1/3 w-64 h-64 bg-accent/15 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '0.5s' }} />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="max-w-4xl mx-auto text-center">
          <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-primary/10 border border-primary/30 backdrop-blur-sm mb-8">
            <Sparkles className="h-4 w-4 text-primary" />
            <span className="text-sm font-medium text-foreground">Powered by NASA Earth Observation Data</span>
          </div>
          
          <h1 className="text-5xl md:text-7xl font-bold mb-6 leading-tight">
            Climate change reshapes how{" "}
            <span className="bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent">
              cities grow
            </span>
          </h1>
          
          <p className="text-xl md:text-2xl text-muted-foreground mb-12 max-w-3xl mx-auto leading-relaxed">
            Our app demonstrates how urban planners can use NASA Earth observation data to design strategies that balance human wellbeing, environmental sustainability, and resilient infrastructure.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
          <Button 
            asChild 
            size="lg"
            className="bg-gradient-to-r from-primary to-secondary hover:opacity-90 transition-all text-lg px-8 shadow-[var(--glow-grey)] hover:shadow-[var(--glow-cosmic)]"
          >
            <Link to="/dashboard">
              Explore Dashboard <ArrowRight className="ml-2 h-5 w-5" />
            </Link>
          </Button>
            <Button 
              asChild 
              size="lg" 
              variant="outline"
              className="border-border backdrop-blur-sm hover:bg-muted/50 text-lg px-8"
            >
              <a href="#about">Learn More</a>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Hero;
