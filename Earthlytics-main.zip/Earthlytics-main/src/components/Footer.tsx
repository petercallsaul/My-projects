import logoIcon from "@/assets/logo-icon.png";
import { Link } from "react-router-dom";

const Footer = () => {
  return (
    <footer className="bg-card border-t border-border py-12">
      <div className="container mx-auto px-6">
        <div className="grid md:grid-cols-3 gap-8 mb-8">
          <div>
            <div className="flex items-center gap-3 mb-4">
              <img src={logoIcon} alt="Earthlytics Logo" className="h-8 w-8" />
              <h3 className="text-xl font-bold bg-gradient-to-r from-primary to-secondary bg-clip-text text-transparent tracking-wider">
                EARTHLYTICS
              </h3>
            </div>
            <p className="text-muted-foreground text-sm leading-relaxed">
              Empowering cities with NASA Earth observation data for sustainable urban planning and climate resilience.
            </p>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Quick Links</h4>
            <ul className="space-y-2">
              <li>
                <a href="#about" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  About Us
                </a>
              </li>
              <li>
                <a href="#features" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Features
                </a>
              </li>
              <li>
                <Link to="/dashboard" className="text-muted-foreground hover:text-primary transition-colors text-sm">
                  Dashboard
                </Link>
              </li>
            </ul>
          </div>
          
          <div>
            <h4 className="font-semibold mb-4 text-foreground">Powered By</h4>
            <p className="text-muted-foreground text-sm leading-relaxed">
              National Aeronautics and Space Administration (NASA)
            </p>
            <p className="text-xs text-muted-foreground mt-2">
              Earth Observation Data
            </p>
          </div>
        </div>
        
        <div className="pt-8 border-t border-border text-center">
          <p className="text-sm text-muted-foreground">
            © 2025 Earthlytics. All rights reserved.
          </p>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
