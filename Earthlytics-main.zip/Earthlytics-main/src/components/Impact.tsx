import { Button } from "./ui/button";
import { Link } from "react-router-dom";
import { ArrowRight } from "lucide-react";
import spaceGalaxy from "@/assets/space-galaxy.jpg";

const Impact = () => {
  return (
    <section className="py-24 bg-background relative overflow-hidden">
      {/* Space galaxy background */}
      <div className="absolute inset-0">
        <img 
          src={spaceGalaxy} 
          alt="Space galaxy background" 
          className="w-full h-full object-cover opacity-30"
        />
        <div className="absolute inset-0 bg-gradient-to-b from-background/80 via-background/60 to-background/80" />
      </div>
      
      {/* Cosmic glow elements */}
      <div className="absolute inset-0 overflow-hidden pointer-events-none">
        <div className="absolute top-0 right-0 w-96 h-96 bg-primary/20 rounded-full blur-3xl animate-pulse" />
        <div className="absolute bottom-0 left-0 w-96 h-96 bg-secondary/20 rounded-full blur-3xl animate-pulse" style={{ animationDelay: '1s' }} />
      </div>

      <div className="container mx-auto px-6 relative z-10">
        <div className="text-center mb-12">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">Impact</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto" />
        </div>

        <div className="max-w-4xl mx-auto">
          <p className="text-xl text-muted-foreground leading-relaxed text-center mb-8">
            By linking science with urban planning, this platform helps cities create healthier environments, lower climate risks, protect ecosystems, and guide sustainable growth. It fosters collaboration between leaders, planners, and communities, serving not just as a planning tool but as a pathway toward cities that thrive under climate change while safeguarding the future.
          </p>

          <div className="bg-gradient-to-r from-primary to-secondary p-12 rounded-3xl text-primary-foreground text-center shadow-[var(--shadow-elegant)]">
            <h3 className="text-3xl md:text-4xl font-bold mb-4">
              Discover Data-Driven Resilience!
            </h3>
            <p className="text-lg mb-8 opacity-90">
              Powered by NASA Earth observation data
            </p>
            <Button 
              asChild 
              size="lg"
              className="bg-background text-primary hover:bg-background/90 text-lg px-8 shadow-lg"
            >
              <Link to="/dashboard">
                Start Exploring <ArrowRight className="ml-2 h-5 w-5" />
              </Link>
            </Button>
          </div>
        </div>
      </div>
    </section>
  );
};

export default Impact;
