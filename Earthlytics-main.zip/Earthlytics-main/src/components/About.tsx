import { Users, Database, Target } from "lucide-react";
import { Card } from "./ui/card";

const About = () => {
  return (
    <section id="about" className="py-24 bg-muted/30">
      <div className="container mx-auto px-6">
        <div className="text-center mb-16">
          <h2 className="text-4xl md:text-5xl font-bold mb-4">About Us</h2>
          <div className="w-20 h-1 bg-gradient-to-r from-primary to-secondary mx-auto" />
        </div>

        <div className="max-w-4xl mx-auto mb-16">
          <p className="text-lg text-muted-foreground leading-relaxed text-center">
            We are a multidisciplinary team of urban planners, data scientists, and environmental researchers committed to building smarter, more resilient cities. Our diverse backgrounds allow us to bridge the gap between advanced Earth science and practical city planning.
          </p>
        </div>

        <div className="grid md:grid-cols-3 gap-8 max-w-5xl mx-auto">
          <Card className="p-8 text-center hover:shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 border-primary/20 bg-card/50 backdrop-blur-sm">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6 shadow-[var(--glow-grey)]">
              <Users className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-3">Expert Team</h3>
            <p className="text-muted-foreground">
              Urban planners, data scientists, and environmental researchers working together
            </p>
          </Card>

          <Card className="p-8 text-center hover:shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 border-primary/20 bg-card/50 backdrop-blur-sm">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6 shadow-[var(--glow-grey)]">
              <Database className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-3">NASA Data</h3>
            <p className="text-muted-foreground">
              Harnessing Earth observation data for clear insights into environmental challenges
            </p>
          </Card>

          <Card className="p-8 text-center hover:shadow-[var(--shadow-card)] transition-all hover:-translate-y-1 border-primary/20 bg-card/50 backdrop-blur-sm">
            <div className="w-16 h-16 bg-gradient-to-br from-primary to-secondary rounded-full flex items-center justify-center mx-auto mb-6 shadow-[var(--glow-grey)]">
              <Target className="h-8 w-8 text-primary-foreground" />
            </div>
            <h3 className="text-xl font-bold mb-3">Our Mission</h3>
            <p className="text-muted-foreground">
              Empowering decision-makers with data-driven solutions for sustainable cities
            </p>
          </Card>
        </div>
      </div>
    </section>
  );
};

export default About;
