# Welcome to Earthlytics

## Project info

**URL**: "not published"

## How can I edit this code?

You have a few ways to work on your application:

**Use your preferred IDE**

1. Clone the repository:

```sh
git clone <YOUR_GIT_URL>
```

2. Navigate to the project directory:

```sh
cd <YOUR_PROJECT_NAME>
```

3. Install dependencies:

```sh
npm install
```

4. Start the development server with hot-reloading:

```sh
npm run dev
```

**Edit files directly on GitHub**

* Navigate to the file you want to edit.
* Click the pencil icon to edit.
* Commit your changes.

**Use GitHub Codespaces**

* Go to your repository main page.
* Click the green **Code** button → **Codespaces** → **New codespace**.
* Edit files in the Codespace and commit changes.

## Technologies used

* Vite
* TypeScript
* React
* shadcn-ui
* Tailwind CSS

## How can I deploy this project?

You can deploy it using your preferred hosting service (Netlify, Vercel, etc.) following standard React/Vite deployment steps.

## Custom domain

To use a custom domain, configure it through your hosting provider.
