import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Calendar } from "@/components/ui/calendar";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { CalendarIcon, Clock, Shield, User, Star } from "lucide-react";

const Booking = () => {
  const [selectedDate, setSelectedDate] = useState<Date | undefined>(new Date());
  const [selectedTime, setSelectedTime] = useState("");
  const [selectedTherapist, setSelectedTherapist] = useState("");
  const [sessionType, setSessionType] = useState("");
  const [concerns, setConcerns] = useState("");

  const therapists = [
    {
      id: "dr-smith",
      name: "Dr. Sarah Smith",
      specialties: ["Anxiety", "Depression", "PTSD"],
      rating: 4.9,
      experience: "12 years",
      nextAvailable: "Today"
    },
    {
      id: "dr-johnson",
      name: "Dr. Michael Johnson", 
      specialties: ["Relationship", "Trauma", "Addiction"],
      rating: 4.8,
      experience: "8 years",
      nextAvailable: "Tomorrow"
    },
    {
      id: "dr-williams",
      name: "Dr. Emma Williams",
      specialties: ["Adolescent", "Family", "Behavioral"],
      rating: 4.9,
      experience: "15 years", 
      nextAvailable: "Wed"
    }
  ];

  const timeSlots = [
    "9:00 AM", "10:00 AM", "11:00 AM", "12:00 PM",
    "1:00 PM", "2:00 PM", "3:00 PM", "4:00 PM", "5:00 PM"
  ];

  const sessionTypes = [
    { value: "initial", label: "Initial Consultation (60 min)", price: "$120" },
    { value: "standard", label: "Standard Session (50 min)", price: "$100" },
    { value: "extended", label: "Extended Session (90 min)", price: "$180" },
    { value: "crisis", label: "Crisis Support (Available 24/7)", price: "$150" }
  ];

  const handleBooking = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement booking with Supabase
    console.log("Booking:", { selectedDate, selectedTime, selectedTherapist, sessionType, concerns });
  };

  return (
    <div className="container mx-auto p-6 max-w-6xl">
      <div className="space-y-8">
        {/* Header */}
        <div className="text-center space-y-4">
          <h1 className="text-3xl font-bold text-foreground">Book Your Session</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Schedule a secure, anonymous therapy session with one of our licensed professionals.
          </p>
          <Badge variant="secondary" className="bg-primary/10">
            <Shield className="h-3 w-3 mr-1" />
            Your identity remains anonymous to therapists
          </Badge>
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Therapist Selection */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Choose Your Therapist</CardTitle>
                <CardDescription>All therapists are licensed and verified</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                {therapists.map((therapist) => (
                  <div
                    key={therapist.id}
                    className={`p-4 border rounded-lg cursor-pointer transition-all ${
                      selectedTherapist === therapist.id
                        ? "border-primary bg-primary/5"
                        : "border-border hover:border-primary/50"
                    }`}
                    onClick={() => setSelectedTherapist(therapist.id)}
                  >
                    <div className="flex items-start space-x-3">
                      <Avatar>
                        <AvatarFallback>
                          <User className="h-4 w-4" />
                        </AvatarFallback>
                      </Avatar>
                      <div className="flex-1 space-y-2">
                        <div className="flex items-center justify-between">
                          <h3 className="font-semibold">{therapist.name}</h3>
                          <div className="flex items-center space-x-1">
                            <Star className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                            <span className="text-sm">{therapist.rating}</span>
                          </div>
                        </div>
                        <p className="text-sm text-muted-foreground">{therapist.experience} experience</p>
                        <div className="flex flex-wrap gap-1">
                          {therapist.specialties.map((specialty) => (
                            <Badge key={specialty} variant="outline" className="text-xs">
                              {specialty}
                            </Badge>
                          ))}
                        </div>
                        <p className="text-xs text-primary">Next available: {therapist.nextAvailable}</p>
                      </div>
                    </div>
                  </div>
                ))}
              </CardContent>
            </Card>
          </div>

          {/* Date & Time Selection */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Select Date & Time</CardTitle>
                <CardDescription>Choose your preferred session time</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div>
                  <Label className="text-sm font-medium mb-2 block">Date</Label>
                  <Calendar
                    mode="single"
                    selected={selectedDate}
                    onSelect={setSelectedDate}
                    disabled={(date) => date < new Date()}
                    className="rounded-md border"
                  />
                </div>

                <div>
                  <Label className="text-sm font-medium mb-2 block">Time</Label>
                  <div className="grid grid-cols-3 gap-2">
                    {timeSlots.map((time) => (
                      <Button
                        key={time}
                        variant={selectedTime === time ? "default" : "outline"}
                        size="sm"
                        onClick={() => setSelectedTime(time)}
                        className="text-xs"
                      >
                        {time}
                      </Button>
                    ))}
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Session Details & Booking */}
          <div className="space-y-6">
            <Card>
              <CardHeader>
                <CardTitle>Session Details</CardTitle>
                <CardDescription>Complete your booking information</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleBooking} className="space-y-4">
                  <div>
                    <Label htmlFor="session-type">Session Type</Label>
                    <Select value={sessionType} onValueChange={setSessionType}>
                      <SelectTrigger>
                        <SelectValue placeholder="Choose session type" />
                      </SelectTrigger>
                      <SelectContent>
                        {sessionTypes.map((type) => (
                          <SelectItem key={type.value} value={type.value}>
                            <div className="flex justify-between w-full">
                              <span>{type.label}</span>
                              <span className="text-primary font-medium ml-4">{type.price}</span>
                            </div>
                          </SelectItem>
                        ))}
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="concerns">What would you like to discuss? (Optional)</Label>
                    <Textarea
                      id="concerns"
                      placeholder="Share any specific concerns or topics you'd like to address..."
                      value={concerns}
                      onChange={(e) => setConcerns(e.target.value)}
                      className="min-h-[100px]"
                    />
                  </div>

                  {/* Booking Summary */}
                  {selectedDate && selectedTime && selectedTherapist && sessionType && (
                    <Card className="bg-secondary/50">
                      <CardContent className="p-4 space-y-2">
                        <h4 className="font-semibold">Booking Summary</h4>
                        <div className="text-sm space-y-1">
                          <p><CalendarIcon className="h-3 w-3 inline mr-1" />{selectedDate.toDateString()}</p>
                          <p><Clock className="h-3 w-3 inline mr-1" />{selectedTime}</p>
                          <p><User className="h-3 w-3 inline mr-1" />
                            {therapists.find(t => t.id === selectedTherapist)?.name}
                          </p>
                          <p><Badge variant="outline" className="text-xs">
                            {sessionTypes.find(t => t.value === sessionType)?.label}
                          </Badge></p>
                        </div>
                      </CardContent>
                    </Card>
                  )}

                  <Button 
                    type="submit" 
                    className="w-full" 
                    disabled={!selectedDate || !selectedTime || !selectedTherapist || !sessionType}
                  >
                    Book Session
                  </Button>
                </form>
              </CardContent>
            </Card>

            {/* Privacy Notice */}
            <Card className="border-primary/20 bg-primary/5">
              <CardContent className="p-4">
                <div className="flex items-start space-x-2">
                  <Shield className="h-4 w-4 text-primary mt-0.5" />
                  <div className="text-sm">
                    <h4 className="font-medium">Privacy Protection</h4>
                    <p className="text-muted-foreground text-xs mt-1">
                      Your booking information is encrypted and your identity remains anonymous to your therapist.
                    </p>
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Booking;