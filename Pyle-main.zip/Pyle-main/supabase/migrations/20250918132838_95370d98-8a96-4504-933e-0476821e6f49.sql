-- Fix security vulnerability: Remove public access to psychologist data
-- and replace with authenticated-only access

-- Drop the overly permissive policy
DROP POLICY "Anyone can view psychologist info" ON public.psychologists;

-- Create a new policy that requires authentication
CREATE POLICY "Authenticated users can view psychologist info" 
ON public.psychologists 
FOR SELECT 
TO authenticated
USING (true);