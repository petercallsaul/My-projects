# Pyle Chat System Architecture

## 💬 Chat System Overview

Pyle's chat system provides secure, real-time communication between patients, psychologists, AI assistants, and administrators while maintaining strict anonymity and security protocols.

## 🏗️ Architecture Components

### Message Flow Architecture
```mermaid
graph TD
    A[Patient Client] --> B[Encryption Layer]
    C[Psychologist Client] --> B
    D[Admin Client] --> B
    E[AI Service] --> B
    
    B --> F[Authentication Middleware]
    F --> G[Message Validation]
    G --> H[Real-time Engine]
    H --> I[Database Storage]
    
    H --> J[Message Distribution]
    J --> K[Patient Interface]
    J --> L[Psychologist Interface] 
    J --> M[Admin Interface]
    J --> N[AI Processing]
```

### Core Components

#### 1. Message Processing Pipeline
```typescript
interface MessagePipeline {
  // Input validation and sanitization
  validate(message: RawMessage): ValidationResult;
  
  // Encryption before storage
  encrypt(message: ValidMessage): EncryptedMessage;
  
  // Real-time distribution
  distribute(message: EncryptedMessage): Promise<void>;
  
  // AI processing (if enabled)
  processAI(message: EncryptedMessage): Promise<AIResponse>;
}
```

#### 2. Session Management
```typescript
interface ChatSession {
  sessionId: string;
  participants: {
    patient: AnonymousIdentifier;
    psychologist: ProfessionalIdentifier;
    aiEnabled: boolean;
    adminOverview: boolean;
  };
  encryption: {
    sessionKey: string;
    keyRotation: number;
    algorithm: 'AES-256-GCM';
  };
  metadata: {
    createdAt: Date;
    lastActivity: Date;
    messageCount: number;
    status: 'active' | 'paused' | 'ended';
  };
}
```

## 🎨 Message Styling & Attribution

### Sender Types & Visual Identity

#### Patient Messages
```css
.message-patient {
  background: hsl(var(--therapy-patient));
  align-self: flex-start;
  border-radius: 18px 18px 18px 4px;
  margin: 4px 0 4px 12px;
  max-width: 70%;
}

.sender-patient {
  display: "Anonymous Patient";
  color: hsl(var(--foreground));
  font-weight: 500;
}
```

#### Psychologist Messages
```css
.message-psychologist {
  background: hsl(var(--therapy-psychologist));
  align-self: flex-end;
  border-radius: 18px 18px 4px 18px;
  margin: 4px 12px 4px 0;
  max-width: 70%;
}

.sender-psychologist {
  display: therapist.displayName; // "Dr. Sarah Smith"
  color: hsl(var(--foreground));
  font-weight: 500;
}
```

#### Admin Messages
```css
.message-admin {
  background: hsl(var(--therapy-admin));
  align-self: flex-start;
  border-radius: 18px;
  margin: 4px 0;
  max-width: 85%;
  border: 2px solid hsl(var(--primary));
}

.sender-admin {
  display: "Admin" + badge;
  color: hsl(var(--foreground));
  font-weight: 600;
}

.admin-badge {
  background: hsl(var(--primary));
  color: hsl(var(--primary-foreground));
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
}
```

#### AI Assistant Messages
```css
.message-ai {
  background: hsl(var(--therapy-ai));
  align-self: flex-start;
  border-radius: 18px;
  margin: 4px 0;
  max-width: 80%;
  border-left: 4px solid hsl(var(--primary));
}

.sender-ai {
  display: "AI Assistant" + badge;
  color: hsl(var(--muted-foreground));
  font-weight: 500;
}

.ai-badge {
  background: hsl(var(--secondary));
  color: hsl(var(--secondary-foreground));
  font-size: 10px;
  padding: 2px 6px;
  border-radius: 4px;
}
```

### Message Structure
```typescript
interface ChatMessage {
  // Core identification
  id: string;
  sessionId: string;
  
  // Sender information
  sender: {
    type: 'patient' | 'psychologist' | 'admin' | 'ai';
    id: string;           // Encrypted/anonymized ID
    displayName: string;  // Context-appropriate display name
    role?: string;        // Professional title if applicable
  };
  
  // Message content
  content: {
    text: string;         // Encrypted message text
    type: 'text' | 'system' | 'crisis' | 'ai_suggestion';
    metadata?: {
      aiGenerated?: boolean;
      crisisLevel?: 'none' | 'moderate' | 'high' | 'critical';
      interventionType?: string;
    };
  };
  
  // Timing and status
  timestamp: Date;
  status: 'sending' | 'sent' | 'delivered' | 'read' | 'failed';
  
  // Security and audit
  encryption: {
    algorithm: string;
    keyVersion: number;
    checksum: string;
  };
  
  // Display preferences
  display: {
    avatar?: string;
    color: string;
    alignment: 'left' | 'right';
    showBadge: boolean;
    badgeText?: string;
  };
}
```

## 🔄 Real-Time Communication

### Supabase Realtime Integration
```typescript
// Real-time message subscription
const subscribeToMessages = (sessionId: string) => {
  return supabase
    .channel(`chat:${sessionId}`)
    .on(
      'postgres_changes',
      {
        event: 'INSERT',
        schema: 'public',
        table: 'chat_messages',
        filter: `session_id=eq.${sessionId}`
      },
      (payload) => {
        const message = decryptMessage(payload.new);
        displayMessage(message);
        
        // Trigger AI processing if enabled
        if (shouldProcessWithAI(message)) {
          processAIResponse(message);
        }
      }
    )
    .subscribe();
};
```

### Message Delivery States
```typescript
enum MessageStatus {
  SENDING = 'sending',     // Client-side, being sent
  SENT = 'sent',          // Received by server
  DELIVERED = 'delivered', // Delivered to recipient
  READ = 'read',          // Marked as read
  FAILED = 'failed'       // Delivery failed
}

// Visual indicators for each state
const statusIndicators = {
  [MessageStatus.SENDING]: '⏳',
  [MessageStatus.SENT]: '✓',
  [MessageStatus.DELIVERED]: '✓✓',
  [MessageStatus.READ]: '✓✓ (blue)',
  [MessageStatus.FAILED]: '❌'
};
```

## 🛡️ Security Implementation

### End-to-End Encryption
```typescript
class ChatEncryption {
  private sessionKey: CryptoKey;
  
  async encryptMessage(message: string, recipientPublicKey: string): Promise<EncryptedMessage> {
    // Generate per-message encryption
    const iv = crypto.getRandomValues(new Uint8Array(12));
    const encoder = new TextEncoder();
    const data = encoder.encode(message);
    
    // Encrypt with AES-GCM
    const encrypted = await crypto.subtle.encrypt(
      { name: 'AES-GCM', iv },
      this.sessionKey,
      data
    );
    
    return {
      encryptedData: Array.from(new Uint8Array(encrypted)),
      iv: Array.from(iv),
      timestamp: Date.now(),
      algorithm: 'AES-256-GCM'
    };
  }
  
  async decryptMessage(encryptedMessage: EncryptedMessage): Promise<string> {
    const iv = new Uint8Array(encryptedMessage.iv);
    const data = new Uint8Array(encryptedMessage.encryptedData);
    
    const decrypted = await crypto.subtle.decrypt(
      { name: 'AES-GCM', iv },
      this.sessionKey,
      data
    );
    
    const decoder = new TextDecoder();
    return decoder.decode(decrypted);
  }
}
```

### Anonymity Protection
```typescript
// Patient identity anonymization
const anonymizePatientData = (patientId: string, sessionId: string): AnonymousIdentifier => {
  const hash = crypto.subtle.digest('SHA-256', 
    new TextEncoder().encode(`${patientId}:${sessionId}:${ANONYMIZATION_SALT}`)
  );
  
  return {
    anonymousId: `patient_${Buffer.from(hash).toString('hex').substring(0, 8)}`,
    displayName: 'Anonymous Patient',
    avatar: generateAnonymousAvatar(hash),
    sessionBound: true
  };
};

// Different views based on user role
const getMessageView = (message: ChatMessage, viewerRole: UserRole): DisplayMessage => {
  switch (viewerRole) {
    case 'patient':
      return {
        ...message,
        sender: message.sender.type === 'patient' ? 'You' : message.sender.displayName
      };
      
    case 'psychologist':
      return {
        ...message,
        sender: message.sender.type === 'patient' ? 'Anonymous Patient' : message.sender.displayName
      };
      
    case 'admin':
      return {
        ...message,
        sender: message.sender.displayName, // Full access including patient identity
        metadata: { ...message.metadata, fullAuditTrail: true }
      };
      
    default:
      throw new Error('Unauthorized message access');
  }
};
```

## 🤖 AI Integration Points

### AI Response Triggers
```typescript
const aiTriggerConditions = {
  // Automatic triggers
  crisisKeywords: ['suicide', 'kill myself', 'end it all', 'not worth living'],
  emotionalEscalation: (messages: ChatMessage[]) => 
    detectEmotionalIntensityIncrease(messages),
  
  // Opportunistic triggers
  therapeuticMoments: ['I don't know what to do', 'I feel stuck', 'nothing works'],
  skillOpportunities: ['anxiety', 'panic', 'overwhelmed', 'stressed'],
  
  // Time-based triggers
  silenceDetection: 300000, // 5 minutes of silence
  sessionEndApproaching: 600000, // 10 minutes before session end
};

const shouldTriggerAI = (context: ChatContext): AITriggerReason | null => {
  const lastMessages = context.recentMessages.slice(-5);
  
  // Crisis detection - highest priority
  if (containsCrisisKeywords(lastMessages)) {
    return { type: 'crisis', urgency: 'immediate' };
  }
  
  // Emotional support opportunity
  if (detectEmotionalDistress(lastMessages)) {
    return { type: 'support', urgency: 'moderate' };
  }
  
  // Skill suggestion opportunity
  if (detectSkillOpportunity(lastMessages)) {
    return { type: 'skill', urgency: 'low' };
  }
  
  return null;
};
```

### AI Response Integration
```typescript
const processAIResponse = async (trigger: AITriggerReason, context: ChatContext) => {
  try {
    // Generate AI response
    const aiResponse = await generateTherapeuticResponse(trigger, context);
    
    // Validate response safety
    const safetyCheck = await validateResponseSafety(aiResponse);
    if (!safetyCheck.approved) {
      console.warn('AI response blocked:', safetyCheck.reason);
      return;
    }
    
    // Create AI message
    const aiMessage: ChatMessage = {
      id: generateMessageId(),
      sessionId: context.sessionId,
      sender: {
        type: 'ai',
        id: 'ai_assistant',
        displayName: 'AI Assistant',
      },
      content: {
        text: aiResponse.text,
        type: 'ai_suggestion',
        metadata: {
          aiGenerated: true,
          interventionType: trigger.type,
          confidence: aiResponse.confidence
        }
      },
      timestamp: new Date(),
      status: MessageStatus.SENDING,
      // ... other required fields
    };
    
    // Send message through normal pipeline
    await sendMessage(aiMessage);
    
  } catch (error) {
    console.error('AI response processing failed:', error);
    // Fail silently - don't disrupt therapy session
  }
};
```

## 📊 Message Analytics & Monitoring

### Chat Session Metrics
```typescript
interface SessionAnalytics {
  messageCount: {
    patient: number;
    psychologist: number;
    ai: number;
    total: number;
  };
  
  timing: {
    sessionDuration: number;
    averageResponseTime: number;
    longestSilence: number;
  };
  
  engagement: {
    messageLength: { min: number; max: number; avg: number };
    emotionalTone: 'positive' | 'neutral' | 'negative';
    crisisEvents: number;
    aiInterventions: number;
  };
  
  technical: {
    encryptionIntegrity: boolean;
    messageDeliverySuccess: number; // percentage
    connectionStability: number;    // percentage
  };
}
```

### Real-Time Monitoring Dashboard
```typescript
// For admin oversight without breaking patient anonymity
const generateSessionDashboard = (sessions: ChatSession[]): AdminDashboard => {
  return {
    activeSessions: sessions.filter(s => s.metadata.status === 'active').length,
    
    alertSessions: sessions.filter(session => 
      session.analytics.engagement.crisisEvents > 0
    ).map(session => ({
      sessionId: session.sessionId,
      psychologist: session.participants.psychologist,
      alertLevel: calculateAlertLevel(session.analytics),
      lastActivity: session.metadata.lastActivity
    })),
    
    systemHealth: {
      messageDeliveryRate: calculateDeliveryRate(sessions),
      encryptionStatus: 'healthy',
      aiResponseTime: calculateAIResponseTime(sessions),
      serverLoad: getCurrentServerLoad()
    }
  };
};
```

## 🚨 Crisis Intervention Integration

### Crisis Detection Pipeline
```typescript
const crisisDetectionPipeline = {
  // Real-time keyword monitoring
  keywordAnalysis: (message: string): CrisisIndicator[] => {
    const indicators = [];
    
    CRISIS_KEYWORDS.forEach(pattern => {
      if (pattern.regex.test(message.toLowerCase())) {
        indicators.push({
          type: pattern.type,
          severity: pattern.severity,
          matched: pattern.phrase,
          confidence: pattern.confidence
        });
      }
    });
    
    return indicators;
  },
  
  // Sentiment and context analysis
  contextAnalysis: (recentMessages: ChatMessage[]): ContextualRisk => {
    return {
      emotionalTrend: analyzeEmotionalProgression(recentMessages),
      hopelessnessScore: calculateHopelessnessScore(recentMessages),
      supportSystemMentions: detectSupportSystemReferences(recentMessages),
      futurePlanning: detectFuturePlanning(recentMessages)
    };
  },
  
  // Combined risk assessment
  riskAssessment: (indicators: CrisisIndicator[], context: ContextualRisk): RiskLevel => {
    const score = calculateCompositeRiskScore(indicators, context);
    
    if (score >= 0.8) return 'CRITICAL';
    if (score >= 0.6) return 'HIGH';
    if (score >= 0.4) return 'MODERATE';
    return 'LOW';
  }
};
```

### Emergency Response Actions
```typescript
const handleCrisisDetection = async (riskLevel: RiskLevel, sessionId: string) => {
  switch (riskLevel) {
    case 'CRITICAL':
      // Immediate intervention required
      await Promise.all([
        alertCrisisTeam(sessionId),
        displayCrisisResources(sessionId),
        escalateToEmergencyServices(sessionId),
        notifySessionTherapist(sessionId, 'IMMEDIATE')
      ]);
      break;
      
    case 'HIGH':
      // Urgent therapist notification
      await Promise.all([
        notifySessionTherapist(sessionId, 'URGENT'),
        displaySupportResources(sessionId),
        activateEnhancedMonitoring(sessionId)
      ]);
      break;
      
    case 'MODERATE':
      // Enhanced AI support and therapist alert
      await Promise.all([
        notifySessionTherapist(sessionId, 'ENHANCED_SUPPORT'),
        activateAISupportMode(sessionId),
        logRiskEvent(sessionId, riskLevel)
      ]);
      break;
  }
};
```

---

## 💡 Implementation Best Practices

### Performance Optimization
- **Message Batching**: Group multiple messages for efficient transmission
- **Lazy Loading**: Load older messages on demand
- **Connection Pooling**: Maintain persistent connections for active sessions
- **Compression**: Compress message content before encryption

### User Experience
- **Typing Indicators**: Show when other participants are typing
- **Read Receipts**: Optional read status for messages
- **Offline Support**: Queue messages when connection is lost
- **Accessibility**: Screen reader support and keyboard navigation

### Scalability Considerations
- **Horizontal Scaling**: Distribute sessions across multiple servers
- **Message Archival**: Move old messages to cold storage
- **Rate Limiting**: Prevent spam and abuse
- **Load Balancing**: Distribute real-time connections efficiently

---

**The chat system is the heart of Pyle's therapeutic platform, designed to facilitate healing while maintaining the highest standards of security, privacy, and professional care.**
