import { Avatar, AvatarFallback } from "@/components/ui/avatar";
import { Badge } from "@/components/ui/badge";
import { Bot, Shield, User, UserCheck } from "lucide-react";

export interface Message {
  id: string;
  sender: "patient" | "psychologist" | "admin" | "ai";
  text: string;
  timestamp: Date;
  senderName?: string;
}

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  const { sender, text, timestamp, senderName } = message;

  const getSenderConfig = (sender: string) => {
    switch (sender) {
      case "patient":
        return {
          icon: User,
          color: "therapy-patient",
          name: "Anonymous Patient",
          align: "left" as const,
          badge: null,
        };
      case "psychologist":
        return {
          icon: UserCheck,
          color: "therapy-psychologist",
          name: senderName || "Dr. Smith",
          align: "right" as const,
          badge: null,
        };
      case "admin":
        return {
          icon: Shield,
          color: "therapy-admin",
          name: senderName || "Admin",
          align: "left" as const,
          badge: "Admin",
        };
      case "ai":
        return {
          icon: Bot,
          color: "therapy-ai",
          name: "AI Assistant",
          align: "left" as const,
          badge: "AI",
        };
      default:
        return {
          icon: User,
          color: "therapy-patient",
          name: "Unknown",
          align: "left" as const,
          badge: null,
        };
    }
  };

  const config = getSenderConfig(sender);
  const Icon = config.icon;

  return (
    <div className={`flex gap-3 p-4 ${config.align === "right" ? "flex-row-reverse" : ""}`}>
      <Avatar className="h-8 w-8 flex-shrink-0">
        <AvatarFallback className={`bg-${config.color}`}>
          <Icon className="h-4 w-4" />
        </AvatarFallback>
      </Avatar>
      
      <div className={`flex flex-col max-w-[70%] ${config.align === "right" ? "items-end" : "items-start"}`}>
        <div className="flex items-center gap-2 mb-1">
          <span className="text-sm font-medium text-foreground">{config.name}</span>
          {config.badge && (
            <Badge variant="secondary" className="text-xs">
              {config.badge}
            </Badge>
          )}
        </div>
        
        <div className={`rounded-lg px-3 py-2 bg-${config.color} ${
          config.align === "right" ? "rounded-tr-sm" : "rounded-tl-sm"
        }`}>
          <p className="text-sm text-foreground">{text}</p>
        </div>
        
        <span className="text-xs text-muted-foreground mt-1">
          {timestamp.toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}
        </span>
      </div>
    </div>
  );
}