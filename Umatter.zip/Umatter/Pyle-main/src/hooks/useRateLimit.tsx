import { useState, useCallback } from 'react';

interface RateLimitOptions {
  maxAttempts: number;
  windowMs: number;
}

export function useRateLimit({ maxAttempts, windowMs }: RateLimitOptions) {
  const [attempts, setAttempts] = useState<number[]>([]);

  const isRateLimited = useCallback(() => {
    const now = Date.now();
    const validAttempts = attempts.filter(time => now - time < windowMs);
    return validAttempts.length >= maxAttempts;
  }, [attempts, maxAttempts, windowMs]);

  const recordAttempt = useCallback(() => {
    const now = Date.now();
    setAttempts(prev => {
      // Keep only attempts within the time window
      const validAttempts = prev.filter(time => now - time < windowMs);
      return [...validAttempts, now];
    });
  }, [windowMs]);

  const getRemainingTime = useCallback(() => {
    if (!isRateLimited()) return 0;
    
    const now = Date.now();
    const oldestAttempt = Math.min(...attempts);
    return Math.max(0, windowMs - (now - oldestAttempt));
  }, [attempts, isRateLimited, windowMs]);

  return {
    isRateLimited: isRateLimited(),
    recordAttempt,
    getRemainingTime: getRemainingTime(),
    resetAttempts: () => setAttempts([])
  };
}
