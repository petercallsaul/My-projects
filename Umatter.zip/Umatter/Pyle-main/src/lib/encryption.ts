// Message encryption utilities for healthcare data protection
// Uses AES-256-GCM encryption as specified in SECURITY.md

export interface EncryptedMessage {
  encrypted: string;
  iv: string;
}

export class MessageEncryption {
  private static async generateKey(): Promise<CryptoKey> {
    return await crypto.subtle.generateKey(
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  private static async deriveKey(password: string, salt: Uint8Array): Promise<CryptoKey> {
    const passwordKey = await crypto.subtle.importKey(
      'raw',
      new TextEncoder().encode(password),
      'PBKDF2',
      false,
      ['deriveKey']
    );

    return await crypto.subtle.deriveKey(
      {
        name: 'PBKDF2',
        salt: salt,
        iterations: 100000,
        hash: 'SHA-256'
      },
      passwordKey,
      { name: 'AES-GCM', length: 256 },
      false,
      ['encrypt', 'decrypt']
    );
  }

  static async encryptMessage(
    plaintext: string, 
    userKey: string
  ): Promise<EncryptedMessage> {
    try {
      const encoder = new TextEncoder();
      const data = encoder.encode(plaintext);
      
      // Generate random salt and IV
      const salt = crypto.getRandomValues(new Uint8Array(16));
      const iv = crypto.getRandomValues(new Uint8Array(12));
      
      // Derive key from user key + salt
      const key = await this.deriveKey(userKey, salt);
      
      // Encrypt the message
      const encrypted = await crypto.subtle.encrypt(
        { name: 'AES-GCM', iv: iv },
        key,
        data
      );

      // Combine salt + encrypted data
      const combined = new Uint8Array(salt.length + encrypted.byteLength);
      combined.set(salt);
      combined.set(new Uint8Array(encrypted), salt.length);

      return {
        encrypted: this.arrayBufferToBase64(combined),
        iv: this.arrayBufferToBase64(iv)
      };
    } catch (error) {
      console.error('Encryption failed:', error);
      throw new Error('Failed to encrypt message');
    }
  }

  static async decryptMessage(
    encryptedMessage: EncryptedMessage,
    userKey: string
  ): Promise<string> {
    try {
      const encryptedData = this.base64ToArrayBuffer(encryptedMessage.encrypted);
      const iv = this.base64ToArrayBuffer(encryptedMessage.iv);
      
      // Extract salt and encrypted content
      const salt = new Uint8Array(encryptedData.slice(0, 16));
      const encrypted = encryptedData.slice(16);
      
      // Derive key from user key + salt
      const key = await this.deriveKey(userKey, salt);
      
      // Decrypt the message
      const decrypted = await crypto.subtle.decrypt(
        { name: 'AES-GCM', iv: new Uint8Array(iv) },
        key,
        encrypted
      );

      return new TextDecoder().decode(decrypted);
    } catch (error) {
      console.error('Decryption failed:', error);
      throw new Error('Failed to decrypt message');
    }
  }

  private static arrayBufferToBase64(buffer: ArrayBuffer): string {
    const bytes = new Uint8Array(buffer);
    let binary = '';
    for (let i = 0; i < bytes.byteLength; i++) {
      binary += String.fromCharCode(bytes[i]);
    }
    return btoa(binary);
  }

  private static base64ToArrayBuffer(base64: string): ArrayBuffer {
    const binary = atob(base64);
    const bytes = new Uint8Array(binary.length);
    for (let i = 0; i < binary.length; i++) {
      bytes[i] = binary.charCodeAt(i);
    }
    return bytes.buffer;
  }

  // Generate a user-specific encryption key from their session
  static generateUserKey(userId: string, sessionId: string): string {
    // In production, this should use proper key derivation
    // For now, create a deterministic key from user/session data
    return `${userId}-${sessionId}-${new Date().toDateString()}`;
  }
}