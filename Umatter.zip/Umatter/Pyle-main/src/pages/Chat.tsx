import { useState, useRef, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Badge } from "@/components/ui/badge";
import { ChatMessage, type Message } from "@/components/ChatMessage";
import { Send, Bot, Shield, AlertCircle } from "lucide-react";

const Chat = () => {
  const [messages, setMessages] = useState<Message[]>([
    {
      id: "1",
      sender: "psychologist",
      text: "Hello, I'm Dr. Smith. Welcome to your secure therapy session. How are you feeling today?",
      timestamp: new Date(Date.now() - 300000),
      senderName: "Dr. Smith"
    },
    {
      id: "2",
      sender: "patient",
      text: "Hi Dr. Smith, I'm feeling a bit anxious about work lately. It's been overwhelming.",
      timestamp: new Date(Date.now() - 240000)
    },
    {
      id: "3",
      sender: "psychologist",
      text: "I understand that work stress can be really challenging. Can you tell me more about what specifically is making you feel overwhelmed?",
      timestamp: new Date(Date.now() - 180000),
      senderName: "Dr. Smith"
    }
  ]);

  const [newMessage, setNewMessage] = useState("");
  const [aiEnabled, setAiEnabled] = useState(false);
  const [isTyping, setIsTyping] = useState(false);
  const messagesEndRef = useRef<HTMLDivElement>(null);

  const scrollToBottom = () => {
    messagesEndRef.current?.scrollIntoView({ behavior: "smooth" });
  };

  useEffect(() => {
    scrollToBottom();
  }, [messages]);

  const handleSendMessage = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!newMessage.trim()) return;

    const userMessage: Message = {
      id: Date.now().toString(),
      sender: "patient",
      text: newMessage.trim(),
      timestamp: new Date()
    };

    setMessages(prev => [...prev, userMessage]);
    setNewMessage("");

    // Simulate psychologist response
    setIsTyping(true);
    setTimeout(() => {
      const psychologistResponse: Message = {
        id: (Date.now() + 1).toString(),
        sender: "psychologist",
        text: "That sounds really difficult. It's completely normal to feel overwhelmed when facing increased responsibilities. What strategies have you tried so far to manage this stress?",
        timestamp: new Date(),
        senderName: "Dr. Smith"
      };
      setMessages(prev => [...prev, psychologistResponse]);
      setIsTyping(false);

      // AI response if enabled
      if (aiEnabled) {
        setTimeout(() => {
          const aiResponse: Message = {
            id: (Date.now() + 2).toString(),
            sender: "ai",
            text: "I've noticed you mentioned feeling overwhelmed. Some evidence-based techniques that might help include deep breathing exercises, time-blocking your tasks, and setting boundaries at work. Would you like me to guide you through a quick breathing exercise?",
            timestamp: new Date()
          };
          setMessages(prev => [...prev, aiResponse]);
        }, 2000);
      }
    }, 1500);
  };

  return (
    <div className="container mx-auto p-6 max-w-4xl">
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-2xl font-bold text-foreground">Therapy Session</h1>
            <p className="text-muted-foreground">Secure, encrypted conversation</p>
          </div>
          <div className="flex items-center space-x-4">
            <Badge variant="secondary" className="bg-primary/10">
              <Shield className="h-3 w-3 mr-1" />
              End-to-End Encrypted
            </Badge>
            <Badge variant="outline">Session Active</Badge>
          </div>
        </div>

        {/* AI Toggle */}
        <Card>
          <CardContent className="p-4">
            <div className="flex items-center justify-between">
              <div className="flex items-center space-x-3">
                <Bot className="h-5 w-5 text-primary" />
                <div>
                  <Label htmlFor="ai-mode" className="font-medium">AI Support Assistant</Label>
                  <p className="text-sm text-muted-foreground">Get additional AI-powered insights during your session</p>
                </div>
              </div>
              <Switch
                id="ai-mode"
                checked={aiEnabled}
                onCheckedChange={setAiEnabled}
              />
            </div>
          </CardContent>
        </Card>

        {/* Chat Area */}
        <Card className="h-[500px] flex flex-col">
          <CardHeader className="pb-3">
            <CardTitle className="flex items-center space-x-2 text-lg">
              <Shield className="h-5 w-5" />
              <span>Private Chat Room</span>
            </CardTitle>
          </CardHeader>
          
          <CardContent className="flex-1 flex flex-col p-0">
            {/* Messages */}
            <div className="flex-1 overflow-y-auto border-b">
              {messages.map((message) => (
                <ChatMessage key={message.id} message={message} />
              ))}
              
              {isTyping && (
                <div className="flex gap-3 p-4">
                  <div className="flex items-center space-x-2 text-muted-foreground">
                    <div className="flex space-x-1">
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce"></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.1s' }}></div>
                      <div className="w-2 h-2 bg-primary rounded-full animate-bounce" style={{ animationDelay: '0.2s' }}></div>
                    </div>
                    <span className="text-sm">Dr. Smith is typing...</span>
                  </div>
                </div>
              )}
              
              <div ref={messagesEndRef} />
            </div>

            {/* Message Input */}
            <form onSubmit={handleSendMessage} className="p-4">
              <div className="flex space-x-2">
                <Input
                  value={newMessage}
                  onChange={(e) => setNewMessage(e.target.value)}
                  placeholder="Type your message... (encrypted)"
                  className="flex-1"
                />
                <Button type="submit" disabled={!newMessage.trim()}>
                  <Send className="h-4 w-4" />
                </Button>
              </div>
            </form>
          </CardContent>
        </Card>

        {/* Emergency Support */}
        <Card className="border-destructive/20 bg-destructive/5">
          <CardContent className="p-4">
            <div className="flex items-center space-x-3">
              <AlertCircle className="h-5 w-5 text-destructive" />
              <div className="flex-1">
                <h3 className="font-semibold text-foreground">Crisis Support Available</h3>
                <p className="text-sm text-muted-foreground">
                  If you're experiencing a mental health crisis, immediate support is available 24/7.
                </p>
              </div>
              <Button variant="destructive" size="sm">
                Emergency Help
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  );
};

export default Chat;