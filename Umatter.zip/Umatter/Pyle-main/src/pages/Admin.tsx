import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Badge } from "@/components/ui/badge";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Shield, Users, MessageCircle, Activity, Plus, Eye, Trash2, RefreshCw } from "lucide-react";

const Admin = () => {
  const [newUser, setNewUser] = useState({
    name: "",
    email: "",
    role: "",
    password: ""
  });

  // Mock data - in real app this would come from Supabase
  const users = [
    { id: 1, name: "Dr. Sarah Smith", email: "dr.smith@pyle.com", role: "psychologist", status: "active", lastLogin: "2024-01-15 14:30" },
    { id: 2, name: "Anonymous Patient #001", email: "patient001@pyle.com", role: "patient", status: "active", lastLogin: "2024-01-15 16:45" },
    { id: 3, name: "Dr. Michael Johnson", email: "dr.johnson@pyle.com", role: "psychologist", status: "active", lastLogin: "2024-01-14 11:20" },
    { id: 4, name: "Anonymous Patient #002", email: "patient002@pyle.com", role: "patient", status: "inactive", lastLogin: "2024-01-10 09:15" },
  ];

  const sessions = [
    { id: 1, patient: "Patient #001", therapist: "Dr. Smith", date: "2024-01-15", duration: "50 min", status: "completed", encrypted: true },
    { id: 2, patient: "Patient #002", therapist: "Dr. Johnson", date: "2024-01-15", duration: "45 min", status: "active", encrypted: true },
    { id: 3, patient: "Patient #001", therapist: "Dr. Smith", date: "2024-01-14", duration: "50 min", status: "completed", encrypted: true },
  ];

  const auditLogs = [
    { id: 1, admin: "Admin User", action: "Created new user", target: "patient003@pyle.com", timestamp: "2024-01-15 15:30:22", ip: "192.168.1.1" },
    { id: 2, admin: "Admin User", action: "Viewed chat logs", target: "Session #125", timestamp: "2024-01-15 14:15:10", ip: "192.168.1.1" },
    { id: 3, admin: "Admin User", action: "Reset password", target: "dr.smith@pyle.com", timestamp: "2024-01-14 09:45:33", ip: "192.168.1.1" },
    { id: 4, admin: "Admin User", action: "Deleted user", target: "inactive@pyle.com", timestamp: "2024-01-13 16:20:15", ip: "192.168.1.1" },
  ];

  const handleCreateUser = (e: React.FormEvent) => {
    e.preventDefault();
    // TODO: Implement user creation with Supabase
    console.log("Creating user:", newUser);
    setNewUser({ name: "", email: "", role: "", password: "" });
  };

  const stats = [
    { title: "Total Users", value: "147", icon: Users, change: "+12 this week" },
    { title: "Active Sessions", value: "23", icon: MessageCircle, change: "+5 today" },
    { title: "Security Events", value: "0", icon: Shield, change: "All secure" },
    { title: "System Health", value: "99.9%", icon: Activity, change: "Optimal" },
  ];

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Admin Dashboard</h1>
          <p className="text-muted-foreground">Secure administration panel for Pyle platform</p>
        </div>
        <Badge variant="secondary" className="bg-primary/10">
          <Shield className="h-3 w-3 mr-1" />
          Authenticated Admin
        </Badge>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        {stats.map((stat, index) => {
          const Icon = stat.icon;
          return (
            <Card key={index}>
              <CardContent className="p-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{stat.title}</p>
                    <p className="text-2xl font-bold">{stat.value}</p>
                    <p className="text-xs text-primary">{stat.change}</p>
                  </div>
                  <Icon className="h-8 w-8 text-primary" />
                </div>
              </CardContent>
            </Card>
          );
        })}
      </div>

      {/* Main Content Tabs */}
      <Tabs defaultValue="users" className="space-y-6">
        <TabsList className="grid w-full grid-cols-4">
          <TabsTrigger value="users">User Management</TabsTrigger>
          <TabsTrigger value="sessions">Session Oversight</TabsTrigger>
          <TabsTrigger value="logs">Audit Logs</TabsTrigger>
          <TabsTrigger value="security">Security</TabsTrigger>
        </TabsList>

        {/* User Management */}
        <TabsContent value="users" className="space-y-6">
          <div className="grid lg:grid-cols-3 gap-6">
            <Card className="lg:col-span-2">
              <CardHeader>
                <CardTitle>System Users</CardTitle>
                <CardDescription>Manage patient, psychologist, and admin accounts</CardDescription>
              </CardHeader>
              <CardContent>
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Name</TableHead>
                      <TableHead>Role</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead>Last Login</TableHead>
                      <TableHead>Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {users.map((user) => (
                      <TableRow key={user.id}>
                        <TableCell className="font-medium">{user.name}</TableCell>
                        <TableCell>
                          <Badge variant={user.role === 'admin' ? 'default' : 'secondary'}>
                            {user.role}
                          </Badge>
                        </TableCell>
                        <TableCell>
                          <Badge variant={user.status === 'active' ? 'default' : 'secondary'}>
                            {user.status}
                          </Badge>
                        </TableCell>
                        <TableCell className="text-sm text-muted-foreground">{user.lastLogin}</TableCell>
                        <TableCell>
                          <div className="flex space-x-2">
                            <Button size="sm" variant="outline">
                              <RefreshCw className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="outline">
                              <Eye className="h-3 w-3" />
                            </Button>
                            <Button size="sm" variant="destructive">
                              <Trash2 className="h-3 w-3" />
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>Create New User</CardTitle>
                <CardDescription>Add a new user to the system</CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleCreateUser} className="space-y-4">
                  <div>
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={newUser.name}
                      onChange={(e) => setNewUser({ ...newUser, name: e.target.value })}
                      required
                    />
                  </div>
                  
                  <div>
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={newUser.email}
                      onChange={(e) => setNewUser({ ...newUser, email: e.target.value })}
                      required
                    />
                  </div>

                  <div>
                    <Label htmlFor="role">Role</Label>
                    <Select value={newUser.role} onValueChange={(value) => setNewUser({ ...newUser, role: value })}>
                      <SelectTrigger>
                        <SelectValue placeholder="Select role" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="patient">Patient</SelectItem>
                        <SelectItem value="psychologist">Psychologist</SelectItem>
                        <SelectItem value="admin">Administrator</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div>
                    <Label htmlFor="password">Temporary Password</Label>
                    <Input
                      id="password"
                      type="password"
                      value={newUser.password}
                      onChange={(e) => setNewUser({ ...newUser, password: e.target.value })}
                      required
                    />
                  </div>

                  <Button type="submit" className="w-full">
                    <Plus className="h-4 w-4 mr-2" />
                    Create User
                  </Button>
                </form>
              </CardContent>
            </Card>
          </div>
        </TabsContent>

        {/* Session Oversight */}
        <TabsContent value="sessions">
          <Card>
            <CardHeader>
              <CardTitle>Active & Recent Sessions</CardTitle>
              <CardDescription>Monitor therapy sessions and chat rooms</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Session ID</TableHead>
                    <TableHead>Patient</TableHead>
                    <TableHead>Therapist</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Duration</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Security</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {sessions.map((session) => (
                    <TableRow key={session.id}>
                      <TableCell className="font-mono">#{session.id.toString().padStart(3, '0')}</TableCell>
                      <TableCell>{session.patient}</TableCell>
                      <TableCell>{session.therapist}</TableCell>
                      <TableCell>{session.date}</TableCell>
                      <TableCell>{session.duration}</TableCell>
                      <TableCell>
                        <Badge variant={session.status === 'active' ? 'default' : 'secondary'}>
                          {session.status}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        {session.encrypted && (
                          <Badge variant="outline" className="text-xs">
                            <Shield className="h-2 w-2 mr-1" />
                            Encrypted
                          </Badge>
                        )}
                      </TableCell>
                      <TableCell>
                        <Button size="sm" variant="outline">
                          <Eye className="h-3 w-3 mr-1" />
                          View Logs
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Audit Logs */}
        <TabsContent value="logs">
          <Card>
            <CardHeader>
              <CardTitle>System Audit Logs</CardTitle>
              <CardDescription>Track all administrative actions and security events</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Timestamp</TableHead>
                    <TableHead>Admin</TableHead>
                    <TableHead>Action</TableHead>
                    <TableHead>Target</TableHead>
                    <TableHead>IP Address</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {auditLogs.map((log) => (
                    <TableRow key={log.id}>
                      <TableCell className="font-mono text-sm">{log.timestamp}</TableCell>
                      <TableCell>{log.admin}</TableCell>
                      <TableCell>
                        <Badge variant="outline">{log.action}</Badge>
                      </TableCell>
                      <TableCell className="font-mono">{log.target}</TableCell>
                      <TableCell className="font-mono text-sm">{log.ip}</TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Security */}
        <TabsContent value="security">
          <div className="grid gap-6">
            <Card>
              <CardHeader>
                <CardTitle>Security Overview</CardTitle>
                <CardDescription>System security status and controls</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <Shield className="h-8 w-8 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium">Encryption</p>
                    <p className="text-xs text-muted-foreground">AES-256 Active</p>
                  </div>
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <Users className="h-8 w-8 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium">2FA</p>
                    <p className="text-xs text-muted-foreground">Enforced</p>
                  </div>
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <Activity className="h-8 w-8 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium">Rate Limiting</p>
                    <p className="text-xs text-muted-foreground">Active</p>
                  </div>
                  <div className="text-center p-4 bg-primary/5 rounded-lg">
                    <Shield className="h-8 w-8 text-primary mx-auto mb-2" />
                    <p className="text-sm font-medium">Intrusion Detection</p>
                    <p className="text-xs text-muted-foreground">Monitoring</p>
                  </div>
                </div>

                <div className="space-y-2">
                  <h4 className="font-semibold">Security Policies</h4>
                  <ul className="text-sm space-y-1 text-muted-foreground">
                    <li>• Password complexity: 12+ characters with mixed case, numbers, symbols</li>
                    <li>• Session timeout: 30 minutes of inactivity</li>
                    <li>• Failed login lockout: 5 attempts</li>
                    <li>• Data retention: 7 years (encrypted)</li>
                    <li>• Audit log retention: 10 years</li>
                  </ul>
                </div>
              </CardContent>
            </Card>
          </div>
        </TabsContent>
      </Tabs>
    </div>
  );
};

export default Admin;