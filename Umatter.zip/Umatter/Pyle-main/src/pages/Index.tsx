import { Link } from "react-router-dom";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { ThemeToggle } from "@/components/ThemeToggle";
import { Shield, Lock, Brain, MessageCircle, Users, Zap, CheckCircle } from "lucide-react";
import { useAuth } from "@/hooks/useAuth";
import { useEffect } from "react";
import { useNavigate } from "react-router-dom";

const Index = () => {
  const { user } = useAuth();
  const navigate = useNavigate();

  // Redirect authenticated users to dashboard
  useEffect(() => {
    if (user) {
      navigate('/dashboard');
    }
  }, [user, navigate]);
  const features = [
    {
      icon: Shield,
      title: "End-to-End Encryption",
      description: "AES-256 encryption ensures your conversations remain completely private and secure."
    },
    {
      icon: Lock,
      title: "Anonymous Sessions",
      description: "Patients remain anonymous to psychologists while admins maintain oversight capabilities."
    },
    {
      icon: Brain,
      title: "AI-Powered Support",
      description: "Optional AI assistant provides additional support and guidance during therapy sessions."
    },
    {
      icon: Users,
      title: "Multi-Role System",
      description: "Secure role-based access for patients, psychologists, and administrators."
    },
    {
      icon: Zap,
      title: "Real-Time Chat",
      description: "Instant, secure messaging with professional therapists in private chat rooms."
    },
    {
      icon: MessageCircle,
      title: "Session Booking",
      description: "Easy appointment scheduling system connecting you with qualified therapists."
    }
  ];

  const benefits = [
    "HIPAA-compliant security standards",
    "24/7 crisis support availability",
    "Licensed mental health professionals",
    "Flexible scheduling options",
    "Evidence-based therapy approaches",
    "Complete anonymity protection"
  ];

  return (
    <div className="min-h-screen bg-gradient-to-br from-background to-secondary/20">
      {/* Header */}
      <header className="absolute top-0 w-full z-50">
        <div className="container mx-auto flex h-16 items-center justify-between px-4">
          <div className="flex items-center space-x-2">
            <Shield className="h-8 w-8 text-primary" />
            <span className="text-xl font-bold text-foreground">U Matter</span>
          </div>
          <div className="flex items-center space-x-4">
            <ThemeToggle />
            <Link to="/login">
              <Button variant="outline">Login</Button>
            </Link>
            <Link to="/register">
              <Button>Get Started</Button>
            </Link>
          </div>
        </div>
      </header>

      {/* Hero Section */}
      <section className="relative pt-32 pb-20">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-4xl mx-auto">
            <h1 className="text-5xl md:text-7xl font-bold tracking-tight mb-6">
              <span className="text-foreground">Secure</span>{" "}
              <span className="text-primary">Anonymous</span>{" "}
              <span className="text-foreground">Therapy</span>
            </h1>
            <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
              Professional mental health support with military-grade encryption, complete anonymity, 
              and AI-assisted care. Your privacy is our priority.
            </p>
            <div className="flex flex-col sm:flex-row gap-4 justify-center">
              <Link to="/booking">
                <Button size="lg" className="text-lg px-8 py-6">
                  Book a Session
                </Button>
              </Link>
              <Link to="#features">
                <Button variant="outline" size="lg" className="text-lg px-8 py-6">
                  Learn More
                </Button>
              </Link>
            </div>
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section id="features" className="py-20 bg-card/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Why Choose U Matter?
            </h2>
            <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
              Advanced security meets compassionate care in our revolutionary therapy platform.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-8">
            {features.map((feature, index) => {
              const Icon = feature.icon;
              return (
                <Card key={index} className="border-border/50 hover:border-primary/50 transition-all duration-300">
                  <CardContent className="p-6">
                    <div className="flex items-center mb-4">
                      <div className="p-2 rounded-lg bg-primary/10">
                        <Icon className="h-6 w-6 text-primary" />
                      </div>
                      <h3 className="text-lg font-semibold text-foreground ml-3">
                        {feature.title}
                      </h3>
                    </div>
                    <p className="text-muted-foreground">
                      {feature.description}
                    </p>
                  </CardContent>
                </Card>
              );
            })}
          </div>
        </div>
      </section>

      {/* Benefits Section */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="max-w-4xl mx-auto">
            <div className="text-center mb-16">
              <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
                Professional Mental Health Care
              </h2>
              <p className="text-lg text-muted-foreground">
                Experience therapy with the highest standards of security and professionalism.
              </p>
            </div>
            
            <div className="grid md:grid-cols-2 gap-6">
              {benefits.map((benefit, index) => (
                <div key={index} className="flex items-center space-x-3">
                  <CheckCircle className="h-5 w-5 text-primary flex-shrink-0" />
                  <span className="text-foreground">{benefit}</span>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-primary/5">
        <div className="container mx-auto px-4 text-center">
          <div className="max-w-2xl mx-auto">
            <h2 className="text-3xl md:text-4xl font-bold text-foreground mb-4">
              Ready to Start Your Journey?
            </h2>
            <p className="text-lg text-muted-foreground mb-8">
              Take the first step towards better mental health with complete privacy and professional support.
            </p>
            <Link to="/booking">
              <Button size="lg" className="text-lg px-12 py-6">
                Book Your First Session
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t border-border bg-card">
        <div className="container mx-auto px-4 py-8">
          <div className="flex flex-col md:flex-row justify-between items-center">
            <div className="flex items-center space-x-2 mb-4 md:mb-0">
              <Shield className="h-6 w-6 text-primary" />
              <span className="font-semibold text-foreground">U Matter</span>
            </div>
            <p className="text-sm text-muted-foreground">
              © 2024 U Matter. Secure, anonymous therapy platform.
            </p>
          </div>
        </div>
      </footer>
    </div>
  );
};

export default Index;