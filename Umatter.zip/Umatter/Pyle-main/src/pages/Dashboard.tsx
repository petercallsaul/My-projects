import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Calendar, MessageCircle, Shield, Brain, Users, Clock, Activity } from "lucide-react";

const Dashboard = () => {
  // Mock user data - in real app this would come from authentication
  const user = {
    name: "Anonymous User",
    role: "patient",
    sessionsCompleted: 12,
    nextSession: "Today at 3:00 PM",
    therapist: "Dr. Sarah Smith"
  };

  const recentSessions = [
    { id: 1, date: "2024-01-15", duration: "50 min", status: "completed", notes: "Great progress on anxiety management" },
    { id: 2, date: "2024-01-10", duration: "45 min", status: "completed", notes: "Discussed coping strategies" },
    { id: 3, date: "2024-01-05", duration: "50 min", status: "completed", notes: "Initial assessment and goal setting" },
  ];

  const quickActions = [
    { title: "Start Emergency Chat", icon: MessageCircle, variant: "destructive", href: "/chat" },
    { title: "Book New Session", icon: Calendar, variant: "default", href: "/booking" },
    { title: "AI Support Chat", icon: Brain, variant: "secondary", href: "/chat?ai=true" },
    { title: "View Resources", icon: Shield, variant: "outline", href: "#" },
  ];

  return (
    <div className="container mx-auto p-6 space-y-8">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-3xl font-bold text-foreground">Dashboard</h1>
          <p className="text-muted-foreground">Welcome back to your secure therapy space</p>
        </div>
        <Badge variant="secondary" className="text-sm">
          <Shield className="h-3 w-3 mr-1" />
          Encrypted Session
        </Badge>
      </div>

      {/* Quick Stats */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Activity className="h-5 w-5 text-primary" />
              <span className="text-2xl font-bold">{user.sessionsCompleted}</span>
            </div>
            <p className="text-sm text-muted-foreground">Sessions Completed</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Clock className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Next Session</span>
            </div>
            <p className="text-sm text-muted-foreground">{user.nextSession}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <Users className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Therapist</span>
            </div>
            <p className="text-sm text-muted-foreground">{user.therapist}</p>
          </CardContent>
        </Card>
        
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center space-x-2">
              <MessageCircle className="h-5 w-5 text-primary" />
              <span className="text-sm font-medium">Status</span>
            </div>
            <Badge variant="secondary" className="text-xs">Available</Badge>
          </CardContent>
        </Card>
      </div>

      {/* Quick Actions */}
      <Card>
        <CardHeader>
          <CardTitle>Quick Actions</CardTitle>
          <CardDescription>Access your therapy tools and resources</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
            {quickActions.map((action, index) => {
              const Icon = action.icon;
              return (
                <Button 
                  key={index} 
                  variant={action.variant as any} 
                  className="h-24 flex-col space-y-2"
                  onClick={() => window.location.href = action.href}
                >
                  <Icon className="h-6 w-6" />
                  <span className="text-sm text-center">{action.title}</span>
                </Button>
              );
            })}
          </div>
        </CardContent>
      </Card>

      {/* Recent Sessions */}
      <Card>
        <CardHeader>
          <CardTitle>Recent Sessions</CardTitle>
          <CardDescription>Your therapy session history</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {recentSessions.map((session) => (
              <div key={session.id} className="flex items-center justify-between p-4 bg-secondary/50 rounded-lg">
                <div className="space-y-1">
                  <p className="font-medium">{new Date(session.date).toLocaleDateString()}</p>
                  <p className="text-sm text-muted-foreground">{session.duration} • {session.notes}</p>
                </div>
                <Badge variant="outline">{session.status}</Badge>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      {/* Privacy Notice */}
      <Card className="border-primary/20 bg-primary/5">
        <CardContent className="p-6">
          <div className="flex items-start space-x-3">
            <Shield className="h-5 w-5 text-primary mt-0.5" />
            <div>
              <h3 className="font-semibold text-foreground">Your Privacy is Protected</h3>
              <p className="text-sm text-muted-foreground mt-1">
                All conversations are encrypted end-to-end with AES-256 encryption. Your identity remains 
                anonymous to therapists while maintaining full clinical oversight.
              </p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  );
};

export default Dashboard;